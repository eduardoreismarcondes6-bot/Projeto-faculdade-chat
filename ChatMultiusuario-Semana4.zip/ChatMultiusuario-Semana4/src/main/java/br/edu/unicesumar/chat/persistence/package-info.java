/** Contratos de persistência independentes da tecnologia de banco de dados. */
package br.edu.unicesumar.chat.persistence;
