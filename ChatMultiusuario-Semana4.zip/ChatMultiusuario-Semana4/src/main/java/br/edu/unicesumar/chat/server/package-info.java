/** Componentes de infraestrutura responsáveis pela comunicação TCP. */
package br.edu.unicesumar.chat.server;
