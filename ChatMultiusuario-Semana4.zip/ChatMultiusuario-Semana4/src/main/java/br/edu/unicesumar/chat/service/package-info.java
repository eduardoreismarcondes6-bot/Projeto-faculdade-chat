/** Contratos e serviços do chat, independentes de detalhes de rede e JDBC. */
package br.edu.unicesumar.chat.service;
