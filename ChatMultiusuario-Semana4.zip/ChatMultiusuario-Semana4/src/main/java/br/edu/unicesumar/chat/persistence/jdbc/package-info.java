/** Implementações de persistência que concentram o acesso JDBC e as instruções SQL. */
package br.edu.unicesumar.chat.persistence.jdbc;
