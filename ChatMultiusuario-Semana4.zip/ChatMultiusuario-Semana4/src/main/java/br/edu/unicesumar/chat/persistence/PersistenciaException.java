package br.edu.unicesumar.chat.persistence;

/**
 * Encapsula falhas de infraestrutura de persistência sem expor SQLException.
 */
public class PersistenciaException extends RuntimeException {
    private static final long serialVersionUID = 1L;

    public PersistenciaException(String mensagem, Throwable causa) {
        super(mensagem, causa);
    }
}
