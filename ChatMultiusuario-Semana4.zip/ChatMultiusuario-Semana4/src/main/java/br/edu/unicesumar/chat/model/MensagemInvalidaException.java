package br.edu.unicesumar.chat.model;

/**
 * Indica que uma mensagem não atende às regras do domínio.
 */
public class MensagemInvalidaException extends RuntimeException {
    private static final long serialVersionUID = 1L;

    public MensagemInvalidaException(String mensagem) {
        super(mensagem);
    }
}
