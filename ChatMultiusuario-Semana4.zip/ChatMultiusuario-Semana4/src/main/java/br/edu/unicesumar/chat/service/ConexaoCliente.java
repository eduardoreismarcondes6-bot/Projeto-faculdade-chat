package br.edu.unicesumar.chat.service;

import br.edu.unicesumar.chat.model.Usuario;

/** Representa uma conexão ativa sem expor detalhes de Socket à camada de serviço. */
public interface ConexaoCliente {
    Usuario getUsuario();
    void enviar(String linha);
}
