/** Leitura e validação de configurações externas da aplicação. */
package br.edu.unicesumar.chat.config;
