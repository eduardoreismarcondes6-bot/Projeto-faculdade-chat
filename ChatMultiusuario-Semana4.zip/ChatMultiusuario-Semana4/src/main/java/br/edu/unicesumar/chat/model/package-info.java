/** Entidades e regras centrais do domínio. Este pacote não depende de infraestrutura, rede ou persistência. */
package br.edu.unicesumar.chat.model;
