/** Aplicações cliente que se comunicam com o servidor exclusivamente pela rede. */
package br.edu.unicesumar.chat.client;
