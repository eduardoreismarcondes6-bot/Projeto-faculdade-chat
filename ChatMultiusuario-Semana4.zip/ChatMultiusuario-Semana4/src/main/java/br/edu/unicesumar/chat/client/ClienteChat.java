package br.edu.unicesumar.chat.client;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.nio.charset.StandardCharsets;

/** Cliente de terminal. Uma thread recebe dados enquanto a principal lê o teclado. */
public final class ClienteChat {
    private ClienteChat() { }

    public static void main(String[] args) {
        String host = args.length > 0 ? args[0] : "localhost";
        int porta = args.length > 1 ? Integer.parseInt(args[1]) : 5000;
        try (Socket socket = new Socket(host, porta);
             BufferedReader entrada = new BufferedReader(new InputStreamReader(
                     socket.getInputStream(), StandardCharsets.UTF_8));
             PrintWriter saida = new PrintWriter(new OutputStreamWriter(
                     socket.getOutputStream(), StandardCharsets.UTF_8), true);
             BufferedReader teclado = new BufferedReader(new InputStreamReader(
                     System.in, StandardCharsets.UTF_8))) {

            Thread leitor = new Thread(() -> {
                try {
                    String linha;
                    while ((linha = entrada.readLine()) != null) System.out.println(linha);
                } catch (IOException e) {
                    System.out.println("Conexão com o servidor encerrada.");
                }
            }, "leitor-servidor");
            leitor.setDaemon(true);
            leitor.start();

            String linha;
            while ((linha = teclado.readLine()) != null) {
                saida.println(linha);
                if ("/sair".equalsIgnoreCase(linha.trim())) break;
            }
        } catch (IOException e) {
            System.err.println("Não foi possível conectar a " + host + ":" + porta + ". " + e.getMessage());
        } catch (NumberFormatException e) {
            System.err.println("Porta inválida. Informe um número entre 1 e 65535.");
        }
    }
}
