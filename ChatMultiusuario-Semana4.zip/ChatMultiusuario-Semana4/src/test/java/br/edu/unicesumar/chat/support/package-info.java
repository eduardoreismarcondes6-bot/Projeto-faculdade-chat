/** Classes auxiliares e implementações em memória utilizadas exclusivamente nos testes. */
package br.edu.unicesumar.chat.support;
