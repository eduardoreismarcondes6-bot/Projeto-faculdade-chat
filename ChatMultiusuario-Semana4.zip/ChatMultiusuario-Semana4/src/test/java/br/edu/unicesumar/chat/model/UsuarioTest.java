package br.edu.unicesumar.chat.model;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class UsuarioTest {
    @Test
    void deveCriarUsuarioComNomeValido() {
        Usuario usuario = new Usuario(" ana ");
        assertEquals("ana", usuario.getNome());
    }

    @Test
    void deveRejeitarNomeVazio() {
        assertThrows(IllegalArgumentException.class, () -> new Usuario("   "));
    }

    @Test
    void deveRejeitarNomeComEspacos() {
        assertThrows(IllegalArgumentException.class, () -> new Usuario("ana maria"));
    }

    @Test
    void usuariosComMesmoNomeIgnorandoMaiusculasDevemSerIguais() {
        assertEquals(new Usuario("Ana"), new Usuario("ana"));
        assertEquals(new Usuario("Ana").hashCode(), new Usuario("ana").hashCode());
    }
    @Test
    void deveRejeitarNomeNulo() {
        assertThrows(IllegalArgumentException.class, () -> new Usuario(null));
    }

    @Test
    void deveRejeitarNomeAcimaDoLimite() {
        String nome = "a".repeat(Usuario.TAMANHO_MAXIMO_NOME + 1);
        assertThrows(IllegalArgumentException.class, () -> new Usuario(nome));
    }

    @Test
    void deveRejeitarEspacoEmBrancoInternoMesmoQueSejaTabulacao() {
        assertThrows(IllegalArgumentException.class, () -> new Usuario("ana\t maria"));
    }

}
