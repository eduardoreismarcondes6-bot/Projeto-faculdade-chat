# Alterações realizadas — Semana 2

- Revisada a organização dos pacotes existentes e documentadas suas responsabilidades.
- Adicionados `package-info.java` para explicitar os limites de `model`, `persistence`, `persistence.jdbc` e `config`.
- Documentada a direção permitida das dependências em `ARQUITETURA.md`.
- Ampliados os testes das regras de `Usuario` e `Mensagem`, cobrindo valores nulos, limites de tamanho, whitespace e identificadores inválidos.
- Adicionada validação para impedir que `Config` seja criada com `Properties` nulo.
- Adicionado `serialVersionUID` às exceções próprias.
- Atualizado o README para explicar a estrutura e a compilação manual no Windows CMD, sem exigir Maven.

## O que não foi implementado de propósito

Servidor TCP, `ClienteHandler`, `ClienteChat`, handshake, threads e broadcast não fazem parte desta etapa. Eles serão implementados conforme as semanas seguintes do cronograma oficial.

## Verificação técnica realizada neste ambiente

- Todas as classes de produção foram compiladas com JDK 21.
- Os fontes de teste foram verificados quanto à compilação usando stubs locais temporários das anotações/assertions JUnit, sem substituir a execução real do JUnit.
- Um programa temporário de smoke test verificou formatação de mensagem, igualdade de usuário, `comId` e valores padrão de configuração.
- A execução real dos 25 testes JUnit não foi possível neste ambiente porque os JARs externos não puderam ser baixados. Execute o comando do README no computador local para confirmar a suíte completa.
