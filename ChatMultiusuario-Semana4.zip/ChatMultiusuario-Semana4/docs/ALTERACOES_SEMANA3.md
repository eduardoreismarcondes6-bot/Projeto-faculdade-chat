# Alterações — Semana 3

## Objetivo

Permitir que vários clientes estabeleçam conexões TCP simultâneas com o servidor, cada uma atendida por uma thread independente. O broadcast permanece fora do escopo desta semana.

## Classes adicionadas

- `server.Servidor`: cria o `ServerSocket`, aguarda conexões com `accept()` e inicia uma thread por `ClienteHandler`. Também fecha o socket de escuta e os clientes no encerramento.
- `server.ClienteHandler`: executa o handshake do nickname e atende uma única conexão. Usa UTF-8, `try-with-resources` e limpeza em `finally`.
- `client.ClienteChat`: conecta ao servidor; uma thread lê as respostas e a thread principal lê o teclado.
- `service.ConexaoCliente`: abstração de uma conexão, sem tipos de rede.
- `service.ClientRegistry`: registro concorrente com `ConcurrentHashMap` e `putIfAbsent`, impedindo nicknames duplicados de forma atômica.

## Fluxo

1. `Servidor` aceita um socket.
2. Cria `ClienteHandler` e inicia uma nova `Thread`.
3. O handler solicita o nickname e tenta registrá-lo.
4. O cliente envia linhas; nesta etapa o servidor apenas registra a mensagem no console e confirma o recebimento ao remetente.
5. `/sair`, fechamento do cliente ou falha de I/O encerra apenas aquela conexão e remove seu registro.

## Concorrência

- Cada socket é manipulado por seu próprio handler.
- `ClientRegistry` usa `ConcurrentHashMap`; `putIfAbsent` torna o cadastro do nickname atômico.
- A lista de conexões não é percorrida para broadcast nesta etapa. A abstração e o registro ficam preparados para evolução posterior.
- `enviar` é sincronizado no handler para proteger escritas caso outras threads precisem usá-lo futuramente.

## Fora do escopo nesta semana

Broadcast para todos os clientes, histórico enviado ao conectar, autenticação e interface gráfica. O broadcast será implementado na Semana 4 e a integração do histórico na Semana 5, conforme o cronograma.
