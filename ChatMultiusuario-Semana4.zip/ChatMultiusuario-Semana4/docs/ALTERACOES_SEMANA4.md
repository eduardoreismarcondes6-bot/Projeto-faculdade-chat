# Alterações — Semana 4

## Objetivo

Implementar a distribuição de mensagens (broadcast) para todos os clientes conectados, inclusive o remetente, preservando a arquitetura definida nas semanas anteriores.

## Arquivos alterados

- `service/ClientRegistry.java`: novo método `broadcast(String mensagem)`, sincronizado e baseado em `snapshot()`.
- `server/ClienteHandler.java`: substitui a confirmação individual pelo envio da mensagem formatada ao registro.
- `service/ClientRegistryTest.java`: testes de broadcast para um e vários clientes, remoção, registro vazio e envios concorrentes.

## Comportamento

Ao receber uma linha não vazia, o handler forma `nome: conteúdo`, registra a mensagem no console do servidor e chama `registro.broadcast(mensagem)`. O registro percorre uma cópia imutável das conexões e distribui a mensagem.

A sincronização do método `broadcast` serializa chamadas concorrentes. Isso ajuda a manter a mesma ordem de distribuição para todos os clientes. Como consequência, o envio para clientes é feito sequencialmente dentro da chamada; uma conexão lenta pode atrasar temporariamente as demais. Melhorias de I/O e tratamento de desconexões abruptas permanecem como assunto de concorrência/I/O das próximas etapas.

## Validação

- Testes JUnit automatizados executados na revisão desta entrega: 34 testes encontrados, 34 aprovados, 0 falhas.
- Teste manual relatado durante o desenvolvimento: três clientes conectados, troca de mensagens, recebimento pelo remetente, desconexão de um cliente sem derrubar o servidor e continuidade da conversa entre os clientes restantes.
