# Arquitetura — Semana 2

## Objetivo

Separar o domínio das preocupações técnicas para que as regras principais possam ser testadas sem rede e sem banco de dados.

## Camadas presentes

| Pacote | Responsabilidade | Pode depender de |
|---|---|---|
| `model` | Entidades e validações do domínio | Java padrão |
| `persistence` | Contratos de persistência | `model` |
| `persistence.jdbc` | Implementação SQL/JDBC | `persistence`, `model`, `config`, `java.sql` |
| `config` | Carregamento de propriedades | Java padrão |
| `support` (testes) | Implementações falsas/em memória para testes | `model`, `persistence` |

## Regras de domínio

### Usuario

- É imutável e valida o nome na construção.
- Remove espaços externos, rejeita nome vazio, espaços internos e nomes acima do limite.
- Compara nomes sem diferenciar maiúsculas e minúsculas.

### Mensagem

- É imutável e representa remetente, conteúdo, horário e, após persistência, identificador.
- Valida remetente, conteúdo, horário e identificador.
- Recebe o horário de fora; não consulta o relógio internamente.
- `comId` cria outra instância em vez de alterar a mensagem original.
- `formatar` centraliza a apresentação padronizada da mensagem.

## Contrato de persistência

`MensagemRepository` define `salvar` e `buscarUltimas` sem expor `Connection`, `PreparedStatement` ou outros tipos JDBC. `JdbcMensagemRepository` implementa esse contrato.

## Decisões importantes

1. **Sem SQL no domínio:** `Usuario` e `Mensagem` não conhecem JDBC.
2. **Sem banco obrigatório nos testes de domínio:** as regras são exercitadas diretamente e o repositório em memória serve como apoio.
3. **Integração JDBC isolada:** os testes de banco usam H2 em memória, sem tocar no banco de desenvolvimento.
4. **Sem sockets nesta etapa:** a especificação oficial reserva o servidor com múltiplas conexões para a Semana 3.

## Próximas dependências previstas

Na etapa de rede, `server` chamará uma camada de serviço e não deverá conter SQL. O cliente se comunicará apenas pela rede, sem conhecer os repositórios. O broadcast e o registro sincronizado de clientes serão adicionados na etapa indicada pelo cronograma.
