# Chat Multiusuário — Semana 4

Projeto acadêmico em Java para o trabalho **Chat Multiusuário com Histórico**. Esta etapa implementa o broadcast: cada mensagem enviada por um cliente é distribuída aos clientes conectados, inclusive ao remetente.

## 1. Requisitos

- JDK 17 ou superior (recomendado usar a mesma instalação para `java` e `javac`).
- H2 2.2.224: `lib\h2-2.2.224.jar`.
- JUnit Platform Console Standalone 1.10.2: `lib\junit-platform-console-standalone-1.10.2.jar`.
- Windows CMD. **Maven não é necessário.**

## 2. Abrir a pasta correta

1. Extraia o ZIP.
2. Abra a pasta interna `ChatMultiusuario-Semana4` no VS Code.
3. Abra **Terminal > Novo Terminal**. O terminal deve estar na pasta que contém `src`, `docs`, `lib`, `README.md` e `testar.bat`.
4. Confira com:

```cmd
cd
dir
```

Se aparecer outra pasta `ChatMultiusuario-Semana4` dentro da pasta atual, entre nela antes de continuar. Não execute os comandos na pasta externa.

## 3. Preparar e conferir o Java

No mesmo CMD em que serão executados os comandos, confira:

```cmd
java -version
javac -version
where java
where javac
```

Use JDK 17 ou superior e garanta que `java` e `javac` apontem para a mesma instalação. Se `java -version` mostrar Java 8 enquanto `javac -version` mostrar uma versão mais nova, o Windows está encontrando instalações diferentes.

Exemplo de ajuste temporário para o JDK 24 instalado no computador usado durante o desenvolvimento (adapte o caminho se sua instalação for diferente):

```cmd
set "JAVA_HOME=C:\Program Files\Eclipse Adoptium\jdk-24.0.2.12-hotspot"
set "PATH=%JAVA_HOME%\bin;%PATH%"
java -version
javac -version
```

Esses comandos valem para o terminal atual. Para não repeti-los em novos terminais, configure `JAVA_HOME` nas Variáveis de Ambiente do Windows e adicione `%JAVA_HOME%\bin` no início de `Path`.

## 4. Preparar as bibliotecas

Crie `lib`, caso ainda não exista, e confira os arquivos:

```cmd
if not exist lib mkdir lib
dir lib
```

Devem existir:

- `h2-2.2.224.jar`
- `junit-platform-console-standalone-1.10.2.jar`

Os dois JARs já acompanham este ZIP. Se estiverem ausentes ou corrompidos, baixe novamente:

```cmd
curl.exe -fL "https://repo.maven.apache.org/maven2/com/h2database/h2/2.2.224/h2-2.2.224.jar" -o "lib\h2-2.2.224.jar"
curl.exe -fL "https://repo.maven.apache.org/maven2/org/junit/platform/junit-platform-console-standalone/1.10.2/junit-platform-console-standalone-1.10.2.jar" -o "lib\junit-platform-console-standalone-1.10.2.jar"
```

Se o download disser que não consegue abrir o destino, confira se a pasta `lib` existe. Se aparecer `Could not resolve host`, verifique a conexão com a internet.

## 5. Compilar e executar os testes

Na raiz do projeto, execute:

```cmd
testar.bat
```

O script compila o código principal, copia os recursos, compila os testes e executa o JUnit. O resultado esperado é **0 tests failed**. O projeto não depende de Maven.

### Compilação manual (alternativa)

```cmd
if not exist out mkdir out
if not exist test-out mkdir test-out
dir /s /b src\main\java\*.java > fontes.txt
javac -encoding UTF-8 -cp "lib\h2-2.2.224.jar" -d out @fontes.txt
xcopy src\main\resources out\ /E /I /Y
dir /s /b src\test\java\*.java > testes.txt
javac -encoding UTF-8 -cp "out;lib\h2-2.2.224.jar;lib\junit-platform-console-standalone-1.10.2.jar" -d test-out @testes.txt
java -jar lib\junit-platform-console-standalone-1.10.2.jar execute --class-path "out;test-out;lib\h2-2.2.224.jar" --scan-class-path
```

## 6. Executar o servidor e conectar clientes

Depois de executar os testes com sucesso, abra um terminal na raiz do projeto e inicie o servidor:

```cmd
java -cp "out;lib\h2-2.2.224.jar" br.edu.unicesumar.chat.server.Servidor
```

O servidor usa a porta `5000` por padrão, definida em `src/main/resources/chat.properties`.

Abra outros terminais na mesma raiz e inicie um cliente em cada um:

```cmd
java -cp "out;lib\h2-2.2.224.jar" br.edu.unicesumar.chat.client.ClienteChat
```

Cada cliente deve informar um nickname diferente. Para conectar outro computador da mesma rede, informe o IP do computador servidor e a porta:

```cmd
java -cp "out;lib\h2-2.2.224.jar" br.edu.unicesumar.chat.client.ClienteChat 192.168.0.10 5000
```

Substitua o IP de exemplo pelo endereço real do servidor. O firewall do Windows pode solicitar autorização para o Java receber conexões. Digite `/sair` para desconectar um cliente; use `Ctrl+C` no terminal do servidor para encerrá-lo.

## 7. O que foi implementado na Semana 4

- `ClientRegistry.broadcast(String)`: distribui cada mensagem para uma cópia da lista de clientes conectados.
- Broadcast sincronizado para serializar distribuições concorrentes e preservar a mesma ordem de mensagens para os destinatários.
- `ClienteHandler` identifica o remetente, monta `nickname: mensagem` e solicita a distribuição para o registro.
- O remetente também recebe sua própria mensagem.
- Testes unitários para broadcast com um e vários clientes, cliente removido, registro vazio e broadcasts concorrentes.
- Mantidos os testes e recursos das semanas anteriores.

## 8. Testes manuais realizados

Na validação manual, foram conectados três clientes. Cada um enviou mensagens e os clientes conectados receberam as mensagens, inclusive o remetente. Também foi testada a saída de um cliente: o servidor permaneceu ativo, a quantidade de conexões foi atualizada e os clientes restantes continuaram conversando.

## 9. Problemas comuns

| Mensagem/problema | Causa provável e solução |
|---|---|
| `UnsupportedClassVersionError` | `java` está mais antigo que `javac` ou que as classes compiladas. Confira `java -version`, `javac -version` e ajuste `JAVA_HOME`/`Path`. Apague `out` e `test-out` e rode `testar.bat` novamente. |
| `error: no source files` | Terminal na pasta errada ou lista de fontes vazia. Confira `cd`, `dir` e a pasta `src`. |
| `Unable to access jarfile` | JAR ausente em `lib`. Confira `dir lib`. |
| `package org.junit... does not exist` | JUnit ausente ou não incluído no classpath. Confira o JAR e execute `testar.bat`. |
| `Address already in use` | Porta 5000 já ocupada. Encerre o outro servidor ou altere `server.port` em `chat.properties`. |
| `Connection refused` | Servidor não iniciado, host/porta incorretos ou firewall bloqueando a conexão. |
| Nickname já conectado | Escolha outro nickname ou encerre a sessão anterior. |

## Próxima etapa

Na Semana 5 será integrada a persistência ao fluxo do chat, para salvar mensagens recebidas e recuperar o histórico quando um cliente entrar.
