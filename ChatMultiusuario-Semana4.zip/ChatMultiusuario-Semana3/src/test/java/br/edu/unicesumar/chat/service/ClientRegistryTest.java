package br.edu.unicesumar.chat.service;

import br.edu.unicesumar.chat.model.Usuario;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class ClientRegistryTest {

    private static final class ConexaoFake implements ConexaoCliente {
        private final Usuario usuario;
        private final List<String> mensagensRecebidas = new ArrayList<>();

        ConexaoFake(String nome) {
            usuario = new Usuario(nome);
        }

        @Override
        public Usuario getUsuario() {
            return usuario;
        }

        @Override
        public void enviar(String linha) {
            mensagensRecebidas.add(linha);
        }

        List<String> getMensagensRecebidas() {
            return mensagensRecebidas;
        }
    }

    @Test
    void registraClienteENumeraConexoes() {
        ClientRegistry registry = new ClientRegistry();

        assertTrue(registry.registrar(new ConexaoFake("ana")));
        assertEquals(1, registry.quantidade());
    }

    @Test
    void impedeNicknameDuplicadoSemDiferenciarMaiusculas() {
        ClientRegistry registry = new ClientRegistry();

        assertTrue(registry.registrar(new ConexaoFake("Ana")));
        assertFalse(registry.registrar(new ConexaoFake("ana")));
        assertEquals(1, registry.quantidade());
    }

    @Test
    void removeSomenteAConexaoRegistrada() {
        ClientRegistry registry = new ClientRegistry();
        ConexaoFake ana = new ConexaoFake("ana");

        registry.registrar(ana);
        registry.remover(new ConexaoFake("ana"));

        assertEquals(1, registry.quantidade());

        registry.remover(ana);

        assertEquals(0, registry.quantidade());
    }

    @Test
    void snapshotNaoPermiteAlterarRegistro() {
        ClientRegistry registry = new ClientRegistry();

        registry.registrar(new ConexaoFake("ana"));

        assertThrows(
                UnsupportedOperationException.class,
                () -> registry.snapshot().clear()
        );
    }

    @Test
    void broadcastEnviaMensagemParaUmCliente() {
        ClientRegistry registry = new ClientRegistry();
        ConexaoFake ana = new ConexaoFake("ana");

        registry.registrar(ana);

        registry.broadcast("Ana: Olá!");

        assertEquals(
                List.of("Ana: Olá!"),
                ana.getMensagensRecebidas()
        );
    }

    @Test
    void broadcastEnviaMensagemParaTodosOsClientes() {
        ClientRegistry registry = new ClientRegistry();

        ConexaoFake ana = new ConexaoFake("ana");
        ConexaoFake bruno = new ConexaoFake("bruno");
        ConexaoFake carla = new ConexaoFake("carla");

        registry.registrar(ana);
        registry.registrar(bruno);
        registry.registrar(carla);

        registry.broadcast("Ana: Bom dia!");

        assertEquals(
                List.of("Ana: Bom dia!"),
                ana.getMensagensRecebidas()
        );

        assertEquals(
                List.of("Ana: Bom dia!"),
                bruno.getMensagensRecebidas()
        );

        assertEquals(
                List.of("Ana: Bom dia!"),
                carla.getMensagensRecebidas()
        );
    }

    @Test
    void clienteRemovidoNaoRecebeNovasMensagens() {
        ClientRegistry registry = new ClientRegistry();

        ConexaoFake ana = new ConexaoFake("ana");
        ConexaoFake bruno = new ConexaoFake("bruno");

        registry.registrar(ana);
        registry.registrar(bruno);

        registry.remover(bruno);

        registry.broadcast("Ana: Mensagem de teste!");

        assertEquals(
                List.of("Ana: Mensagem de teste!"),
                ana.getMensagensRecebidas()
        );

        assertTrue(bruno.getMensagensRecebidas().isEmpty());
    }

    @Test
    void broadcastSemClientesNaoGeraErro() {
        ClientRegistry registry = new ClientRegistry();

        assertDoesNotThrow(
                () -> registry.broadcast("Mensagem sem destinatarios")
        );
    }
}