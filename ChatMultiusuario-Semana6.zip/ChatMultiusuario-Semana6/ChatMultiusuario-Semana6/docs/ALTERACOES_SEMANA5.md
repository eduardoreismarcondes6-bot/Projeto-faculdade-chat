# Alterações — Semana 5

## Objetivo
Integrar a persistência H2 ao fluxo real do chat, armazenando mensagens e recuperando histórico para novos clientes.

## Implementações
- `DatabaseInitializer`: cria a tabela `mensagem` e o índice caso ainda não existam. Não remove nem recria os dados.
- `Servidor`: monta `ConnectionFactory`, inicializa o banco e injeta `JdbcMensagemRepository` no fluxo de conexões.
- `ClienteHandler`: recebe o repositório e o limite do histórico por construtor.
- Mensagens: cria `Mensagem` com remetente e `LocalDateTime.now()`, persiste e usa a versão com ID gerado para formatar o broadcast.
- Histórico: ao entrar, o cliente recebe as últimas mensagens na ordem cronológica, com marcadores de início e fim.
- Falha de persistência: a mensagem não é distribuída se não for salva; o remetente recebe um aviso.
- Envio: `PrintWriter.checkError()` permite transformar falhas de escrita em exceção para que o registro remova a conexão problemática durante broadcast.

## Configuração
`chat.properties` define URL, usuário, senha, porta e quantidade de mensagens de histórico. O padrão é `jdbc:h2:./data/chat` e 50 mensagens.

## Testes
Adicionado `DatabaseInitializerTest`, que verifica inicialização repetida sem perda de dados e integração com `JdbcMensagemRepository`. Os testes existentes de modelo, configuração, repositório JDBC e broadcast foram mantidos.

## Observação
A validação de persistência após reiniciar o servidor deve ser feita também manualmente, seguindo a seção 7 do README. A revisão mais profunda de concorrência e I/O fica para a Semana 6.
