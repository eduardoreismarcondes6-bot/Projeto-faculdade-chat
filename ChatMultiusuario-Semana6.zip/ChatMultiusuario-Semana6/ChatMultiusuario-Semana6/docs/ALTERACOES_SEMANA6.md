# Alterações — Semana 6

## Objetivo

Aumentar a estabilidade do chat sob concorrência e tratar falhas de envio e desconexões inesperadas sem afetar os demais clientes.

## Implementações

1. `ConexaoCliente` ganhou a operação `fechar()`, permitindo que o serviço encerre uma conexão que falhou sem depender de tipos de Socket.
2. `ClientRegistry.broadcast()` mantém uma ordem global de enfileiramento. Como `ClienteHandler.enviar()` agora apenas insere a linha em uma fila limitada, o broadcast não fica aguardando a escrita física na rede.
3. `ClienteHandler` utiliza `ArrayBlockingQueue` com capacidade de 500 linhas e uma thread dedicada para consumir a fila e escrever no socket.
4. A escrita verifica `PrintWriter.checkError()`. Falhas encerram a conexão correspondente.
5. Fila cheia encerra o cliente lento para evitar crescimento ilimitado de memória e bloqueio dos outros clientes.
6. Falhas de envio removem e fecham o cliente no registro, sem interromper o broadcast aos demais.
7. O encerramento do handler interrompe a thread de escrita; o fechamento do socket acorda a thread que estava lendo do cliente.
8. Foi adicionado `ClienteHandlerTest`, usando socket TCP real, para verificar que um fechamento abrupto remove o cliente do registro e termina o handler.
9. Foram adicionados testes do registro para verificar que uma falha de envio fecha/remove somente o cliente problemático e preserva o envio aos demais.

## Validação

- Compilação do código principal: aprovada.
- Compilação dos testes: aprovada.
- JUnit: 37 testes executados, 37 aprovados, 0 falhas.
- O teste de integração de desconexão abrupta confirmou o registro retornando a zero clientes após o fechamento do socket.

## Observação

A fila de saída é limitada a 500 mensagens por cliente. Se um cliente não consumir os dados com velocidade suficiente e a fila lotar, ele será desconectado deliberadamente. Isso evita que um cliente lento prejudique a comunicação dos demais.
