package br.edu.unicesumar.chat.server;

import br.edu.unicesumar.chat.service.ClientRegistry;
import br.edu.unicesumar.chat.support.InMemoryMensagemRepository;
import org.junit.jupiter.api.Test;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;

import static org.junit.jupiter.api.Assertions.*;

class ClienteHandlerTest {

    @Test
    void desconexaoAbruptaRemoveClienteDoRegistro() throws Exception {
        ClientRegistry registro = new ClientRegistry();

        try (ServerSocket servidor = new ServerSocket(0);
             Socket cliente = new Socket("127.0.0.1", servidor.getLocalPort());
             Socket conexaoServidor = servidor.accept();
             BufferedReader entrada = new BufferedReader(new InputStreamReader(
                     cliente.getInputStream(), StandardCharsets.UTF_8));
             PrintWriter saida = new PrintWriter(new OutputStreamWriter(
                     cliente.getOutputStream(), StandardCharsets.UTF_8), true)) {

            cliente.setSoTimeout(3000);
            ClienteHandler handler = new ClienteHandler(
                    conexaoServidor, registro, new InMemoryMensagemRepository(), 10);
            Thread threadHandler = new Thread(handler, "teste-cliente-abrupto");
            threadHandler.start();

            assertEquals("Digite seu nickname:", entrada.readLine());
            saida.println("TesteAbrupto");
            assertEquals("Conectado como TesteAbrupto. Digite /sair para desconectar.",
                    entrada.readLine());
            assertEquals("----- HISTÓRICO (0 mensagens) -----", entrada.readLine());
            assertEquals("Ainda não há mensagens no histórico.", entrada.readLine());
            assertEquals("----- FIM DO HISTÓRICO -----", entrada.readLine());
            assertEquals(1, registro.quantidade());

            // Simula o fechamento inesperado do terminal/rede pelo cliente.
            cliente.close();
            threadHandler.join(3000);

            assertFalse(threadHandler.isAlive(), "O handler deve terminar após a desconexão.");
            assertEquals(0, registro.quantidade(), "O cliente desconectado deve sair do registro.");
        }
    }
}
