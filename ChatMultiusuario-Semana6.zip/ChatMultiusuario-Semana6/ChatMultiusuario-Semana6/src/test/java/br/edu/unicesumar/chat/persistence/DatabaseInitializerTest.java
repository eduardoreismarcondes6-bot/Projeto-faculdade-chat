package br.edu.unicesumar.chat.persistence;

import br.edu.unicesumar.chat.config.Config;
import br.edu.unicesumar.chat.model.Mensagem;
import br.edu.unicesumar.chat.model.Usuario;
import br.edu.unicesumar.chat.persistence.jdbc.ConnectionFactory;
import br.edu.unicesumar.chat.persistence.jdbc.DatabaseInitializer;
import br.edu.unicesumar.chat.persistence.jdbc.JdbcMensagemRepository;
import org.junit.jupiter.api.Test;

import java.util.Properties;

import static org.junit.jupiter.api.Assertions.*;

class DatabaseInitializerTest {
    @Test
    void deveCriarEstruturaEPermitirSalvarMensagem() {
        ConnectionFactory factory = new ConnectionFactory(configurarBanco());
        DatabaseInitializer initializer = new DatabaseInitializer(factory);

        assertDoesNotThrow(initializer::inicializar);
        JdbcMensagemRepository repository = new JdbcMensagemRepository(factory);
        Mensagem salva = repository.salvar(new Mensagem(
                null, new Usuario("teste"), "mensagem inicializada",
                java.time.LocalDateTime.of(2026, 11, 4, 20, 0)));
        assertNotNull(salva.getId());

        // Reinicializar a estrutura não pode apagar mensagens existentes.
        assertDoesNotThrow(initializer::inicializar);
        assertEquals(1, repository.buscarUltimas(10).size());
    }

    private Config configurarBanco() {
        Properties propriedades = new Properties();
        propriedades.setProperty("db.url", "jdbc:h2:mem:initializer;DB_CLOSE_DELAY=-1");
        propriedades.setProperty("db.user", "sa");
        propriedades.setProperty("db.password", "");
        return Config.dePropriedades(propriedades);
    }
}
