package br.edu.unicesumar.chat.server;

import br.edu.unicesumar.chat.config.Config;
import br.edu.unicesumar.chat.persistence.MensagemRepository;
import br.edu.unicesumar.chat.persistence.jdbc.ConnectionFactory;
import br.edu.unicesumar.chat.persistence.jdbc.DatabaseInitializer;
import br.edu.unicesumar.chat.persistence.jdbc.JdbcMensagemRepository;
import br.edu.unicesumar.chat.service.ClientRegistry;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/** Servidor TCP: aceita conexões e cria uma thread independente por cliente. */
public final class Servidor {
    private final int porta;
    private final ClientRegistry registro = new ClientRegistry();
    private final MensagemRepository mensagemRepository;
    private final int quantidadeHistorico;
    private final Set<ClienteHandler> handlers = ConcurrentHashMap.newKeySet();
    private volatile boolean executando = true;
    private volatile ServerSocket servidorSocket;

    /** Construtor principal, permitindo injetar repositório nos testes. */
    public Servidor(int porta, MensagemRepository mensagemRepository, int quantidadeHistorico) {
        if (porta < 1 || porta > 65535) throw new IllegalArgumentException("Porta inválida.");
        if (quantidadeHistorico < 1) {
            throw new IllegalArgumentException("A quantidade de histórico deve ser maior que zero.");
        }
        this.porta = porta;
        this.mensagemRepository = Objects.requireNonNull(
                mensagemRepository, "Repositório de mensagens obrigatório.");
        this.quantidadeHistorico = quantidadeHistorico;
    }

    public void iniciar() throws IOException {
        try (ServerSocket server = new ServerSocket(porta)) {
            servidorSocket = server;
            System.out.println("Servidor iniciado na porta " + porta + ". Aguardando clientes...");
            while (executando) {
                try {
                    Socket socketCliente = server.accept();
                    ClienteHandler handler = new ClienteHandler(
                            socketCliente, registro, mensagemRepository, quantidadeHistorico);
                    handlers.add(handler);
                    Thread thread = new Thread(() -> {
                        try { handler.run(); }
                        finally { handlers.remove(handler); }
                    }, "cliente-" + socketCliente.getPort());
                    thread.start();
                } catch (IOException e) {
                    if (executando) throw e;
                }
            }
        } finally {
            servidorSocket = null;
            fecharClientes();
            System.out.println("Servidor encerrado.");
        }
    }

    public void encerrar() {
        executando = false;
        ServerSocket server = servidorSocket;
        if (server != null) {
            try { server.close(); } catch (IOException ignored) { /* já encerrado */ }
        }
        fecharClientes();
    }

    private void fecharClientes() {
        for (ClienteHandler handler : handlers) handler.fechar();
    }

    public static void main(String[] args) {
        Config config = Config.carregar();
        ConnectionFactory connectionFactory = new ConnectionFactory(config);
        try {
            new DatabaseInitializer(connectionFactory).inicializar();
            MensagemRepository repository = new JdbcMensagemRepository(connectionFactory);
            Servidor servidor = new Servidor(
                    config.getPorta(), repository, config.getQuantidadeHistorico());
            Runtime.getRuntime().addShutdownHook(
                    new Thread(servidor::encerrar, "encerramento-servidor"));
            servidor.iniciar();
        } catch (IOException | RuntimeException e) {
            System.err.println("Não foi possível iniciar o servidor: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
