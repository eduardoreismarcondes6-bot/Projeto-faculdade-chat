package br.edu.unicesumar.chat.service;

import br.edu.unicesumar.chat.model.Usuario;

/** Representa uma conexão ativa sem expor detalhes de Socket à camada de serviço. */
public interface ConexaoCliente {
    Usuario getUsuario();

    /** Enfileira uma linha para envio ao cliente. A operação deve ser rápida e não bloqueante. */
    void enviar(String linha);

    /** Encerra a conexão quando ela não pode mais receber mensagens. */
    void fechar();
}
