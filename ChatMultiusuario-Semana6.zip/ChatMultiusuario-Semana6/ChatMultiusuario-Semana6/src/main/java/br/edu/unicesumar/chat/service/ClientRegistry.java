package br.edu.unicesumar.chat.service;

import br.edu.unicesumar.chat.model.Usuario;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

/** Registro thread-safe dos clientes conectados e distribuição ordenada de mensagens. */
public final class ClientRegistry {
    private final ConcurrentMap<String, ConexaoCliente> clientes = new ConcurrentHashMap<>();

    /** Registra atomicamente; retorna false se o nickname já estiver em uso. */
    public boolean registrar(ConexaoCliente cliente) {
        if (cliente == null || cliente.getUsuario() == null) {
            throw new IllegalArgumentException("A conexão e seu usuário são obrigatórios.");
        }
        return clientes.putIfAbsent(chave(cliente.getUsuario()), cliente) == null;
    }

    public void remover(ConexaoCliente cliente) {
        if (cliente != null && cliente.getUsuario() != null) {
            clientes.remove(chave(cliente.getUsuario()), cliente);
        }
    }

    public int quantidade() {
        return clientes.size();
    }

    public List<ConexaoCliente> snapshot() {
        return List.copyOf(clientes.values());
    }

    /**
     * Enfileira a mensagem para todos os clientes em uma única ordem global.
     * ConexaoCliente.enviar deve apenas inserir na fila de saída, sem fazer I/O de rede.
     * Assim, a sincronização não fica presa aguardando um cliente lento.
     */
    public synchronized void broadcast(String mensagem) {
        if (mensagem == null) {
            throw new IllegalArgumentException("A mensagem não pode ser nula.");
        }

        for (ConexaoCliente cliente : snapshot()) {
            try {
                cliente.enviar(mensagem);
            } catch (RuntimeException e) {
                remover(cliente);
                try {
                    cliente.fechar();
                } catch (RuntimeException ignorada) {
                    // A conexão já está em processo de encerramento.
                }
            }
        }
    }

    private String chave(Usuario usuario) {
        return usuario.getNome().toLowerCase(Locale.ROOT);
    }
}
