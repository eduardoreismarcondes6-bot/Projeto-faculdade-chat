package br.edu.unicesumar.chat.persistence.jdbc;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Objects;

/** Prepara a estrutura mínima do banco antes de o servidor aceitar conexões. */
public final class DatabaseInitializer {
    private final ConnectionFactory connectionFactory;

    public DatabaseInitializer(ConnectionFactory connectionFactory) {
        this.connectionFactory = Objects.requireNonNull(
                connectionFactory, "ConnectionFactory é obrigatória.");
    }

    /** Pode ser executado em todo início do servidor sem apagar os dados existentes. */
    public void inicializar() {
        String criarTabela = """
                CREATE TABLE IF NOT EXISTS mensagem (
                    id BIGINT AUTO_INCREMENT PRIMARY KEY,
                    remetente VARCHAR(30) NOT NULL,
                    conteudo VARCHAR(500) NOT NULL,
                    horario TIMESTAMP NOT NULL
                )
                """;
        String criarIndice = """
                CREATE INDEX IF NOT EXISTS idx_mensagem_horario
                ON mensagem(horario)
                """;

        try (Connection conexao = connectionFactory.obterConexao();
             Statement comando = conexao.createStatement()) {
            comando.execute(criarTabela);
            comando.execute(criarIndice);
        } catch (SQLException e) {
            throw new IllegalStateException("Não foi possível inicializar o banco de dados.", e);
        }
    }
}
