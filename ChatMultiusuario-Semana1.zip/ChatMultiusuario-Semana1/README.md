# Chat Multiusuário — Semana 1

Projeto da Semana 1: modelo de domínio e persistência.

## Requisitos

- JDK 17 ou superior
- Maven 3.9 ou superior (ou Maven integrado à IDE)

## Abrir e executar

1. Extraia o ZIP.
2. Abra a pasta que contém `pom.xml` no IntelliJ IDEA ou Eclipse como projeto Maven.
3. Aguarde o Maven baixar as dependências.
4. Execute os testes com `mvn test`.

## Banco H2

A aplicação está configurada para usar H2 em arquivo:
`jdbc:h2:./data/chat`

O script de criação da tabela está em:
`src/main/resources/schema.sql`

Os testes JDBC usam um banco H2 em memória separado.

## O que está implementado

- `Usuario`: entidade imutável, valida nome e compara nomes sem diferenciar maiúsculas/minúsculas.
- `Mensagem`: entidade imutável, valida conteúdo, recebe horário externamente e formata a mensagem.
- `MensagemRepository`: contrato independente de JDBC.
- `JdbcMensagemRepository`: grava e recupera mensagens com `PreparedStatement`.
- `ConnectionFactory`: abre uma conexão nova por operação.
- `InMemoryMensagemRepository`: implementação em memória usada nos testes.
- `Config`: lê `chat.properties` e aplica padrões se o arquivo não existir.

## Observação sobre os pacotes

Todas as classes usam o pacote-base `br.edu.unicesumar.chat`, com subpacotes por responsabilidade.
