package br.edu.unicesumar.chat.support;

import br.edu.unicesumar.chat.model.Mensagem;
import br.edu.unicesumar.chat.persistence.MensagemRepository;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Repositório em memória para testes unitários, sem banco e sem rede.
 */
public final class InMemoryMensagemRepository implements MensagemRepository {
    private final List<Mensagem> mensagens = new ArrayList<>();
    private final AtomicLong proximoId = new AtomicLong(1);

    @Override
    public synchronized Mensagem salvar(Mensagem mensagem) {
        Mensagem salva = mensagem.comId(proximoId.getAndIncrement());
        mensagens.add(salva);
        return salva;
    }

    @Override
    public synchronized List<Mensagem> buscarUltimas(int quantidade) {
        if (quantidade < 1) {
            throw new IllegalArgumentException("A quantidade deve ser maior que zero.");
        }

        return mensagens.stream()
                .sorted(Comparator.comparing(Mensagem::getId))
                .skip(Math.max(0, mensagens.size() - quantidade))
                .toList();
    }
}
