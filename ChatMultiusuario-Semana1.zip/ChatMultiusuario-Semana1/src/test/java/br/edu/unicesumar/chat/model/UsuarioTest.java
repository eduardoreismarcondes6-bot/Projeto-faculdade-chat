package br.edu.unicesumar.chat.model;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class UsuarioTest {
    @Test
    void deveCriarUsuarioComNomeValido() {
        Usuario usuario = new Usuario(" ana ");
        assertEquals("ana", usuario.getNome());
    }

    @Test
    void deveRejeitarNomeVazio() {
        assertThrows(IllegalArgumentException.class, () -> new Usuario("   "));
    }

    @Test
    void deveRejeitarNomeComEspacos() {
        assertThrows(IllegalArgumentException.class, () -> new Usuario("ana maria"));
    }

    @Test
    void usuariosComMesmoNomeIgnorandoMaiusculasDevemSerIguais() {
        assertEquals(new Usuario("Ana"), new Usuario("ana"));
        assertEquals(new Usuario("Ana").hashCode(), new Usuario("ana").hashCode());
    }
}
