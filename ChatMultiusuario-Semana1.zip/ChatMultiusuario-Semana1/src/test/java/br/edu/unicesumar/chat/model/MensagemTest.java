package br.edu.unicesumar.chat.model;

import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.*;

class MensagemTest {
    private final Usuario remetente = new Usuario("ana");
    private final LocalDateTime horario = LocalDateTime.of(2026, 10, 6, 21, 15);

    @Test
    void deveCriarMensagemValidaEAplicarTrim() {
        Mensagem mensagem = new Mensagem(null, remetente, "  olá  ", horario);
        assertEquals("olá", mensagem.getConteudo());
        assertNull(mensagem.getId());
    }

    @Test
    void deveRejeitarConteudoVazio() {
        assertThrows(MensagemInvalidaException.class,
                () -> new Mensagem(null, remetente, "   ", horario));
    }

    @Test
    void deveRejeitarConteudoAcimaDoLimite() {
        String conteudo = "a".repeat(Mensagem.TAMANHO_MAXIMO_CONTEUDO + 1);
        assertThrows(MensagemInvalidaException.class,
                () -> new Mensagem(null, remetente, conteudo, horario));
    }

    @Test
    void deveFormatarMensagemNoPadraoDefinido() {
        Mensagem mensagem = new Mensagem(null, remetente, "olá", horario);
        assertEquals("[06/10 21:15] ana: olá", mensagem.formatar());
    }

    @Test
    void comIdDeveCriarNovaInstanciaSemAlterarOriginal() {
        Mensagem original = new Mensagem(null, remetente, "olá", horario);
        Mensagem salva = original.comId(10L);

        assertNull(original.getId());
        assertEquals(10L, salva.getId());
        assertNotSame(original, salva);
    }
}
