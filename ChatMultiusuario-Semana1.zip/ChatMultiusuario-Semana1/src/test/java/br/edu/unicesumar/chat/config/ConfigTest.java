package br.edu.unicesumar.chat.config;

import org.junit.jupiter.api.Test;

import java.util.Properties;

import static org.junit.jupiter.api.Assertions.*;

class ConfigTest {
    @Test
    void valoresPadraoDevemSerAplicadosQuandoArquivoNaoDefinePropriedades() {
        Config config = Config.dePropriedades(new Properties());

        assertEquals("jdbc:h2:./data/chat", config.getUrlBanco());
        assertEquals("sa", config.getUsuarioBanco());
        assertEquals(5000, config.getPorta());
        assertEquals(50, config.getQuantidadeHistorico());
    }

    @Test
    void deveLerValoresPersonalizados() {
        Properties propriedades = new Properties();
        propriedades.setProperty("server.port", "6000");
        propriedades.setProperty("chat.history.limit", "100");

        Config config = Config.dePropriedades(propriedades);

        assertEquals(6000, config.getPorta());
        assertEquals(100, config.getQuantidadeHistorico());
    }

    @Test
    void deveRejeitarPortaForaDoIntervalo() {
        Properties propriedades = new Properties();
        propriedades.setProperty("server.port", "70000");

        assertThrows(IllegalArgumentException.class,
                () -> Config.dePropriedades(propriedades));
    }
}
