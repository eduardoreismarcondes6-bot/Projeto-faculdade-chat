package br.edu.unicesumar.chat.persistence;

import br.edu.unicesumar.chat.persistence.jdbc.ConnectionFactory;
import br.edu.unicesumar.chat.persistence.jdbc.JdbcMensagemRepository;
import br.edu.unicesumar.chat.model.Mensagem;
import br.edu.unicesumar.chat.model.Usuario;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.sql.Connection;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class JdbcMensagemRepositoryTest {
    private JdbcMensagemRepository repository;

    @BeforeEach
    void prepararBanco() throws Exception {
        String url = "jdbc:h2:mem:teste;DB_CLOSE_DELAY=-1";
        ConnectionFactory factory = new ConnectionFactory(br.edu.unicesumar.chat.config.Config.dePropriedades(
                propriedadesBanco(url)));
        repository = new JdbcMensagemRepository(factory);

        try (Connection conexao = factory.obterConexao();
             Statement comando = conexao.createStatement()) {
            comando.execute("""
                    CREATE TABLE IF NOT EXISTS mensagem (
                        id BIGINT AUTO_INCREMENT PRIMARY KEY,
                        remetente VARCHAR(30) NOT NULL,
                        conteudo VARCHAR(500) NOT NULL,
                        horario TIMESTAMP NOT NULL
                    )
                    """);
            comando.execute("DELETE FROM mensagem");
        }
    }

    private java.util.Properties propriedadesBanco(String url) {
        java.util.Properties propriedades = new java.util.Properties();
        propriedades.setProperty("db.url", url);
        propriedades.setProperty("db.user", "sa");
        propriedades.setProperty("db.password", "");
        return propriedades;
    }

    @Test
    void devePersistirMensagemEDevolverIdGerado() {
        Mensagem mensagem = novaMensagem("teste JDBC", 10);
        Mensagem salva = repository.salvar(mensagem);

        assertNotNull(salva.getId());
        assertTrue(salva.getId() > 0);
        assertNull(mensagem.getId());
    }

    @Test
    void deveBuscarUltimasMensagensEmOrdemCronologica() {
        repository.salvar(novaMensagem("primeira", 10));
        repository.salvar(novaMensagem("segunda", 11));
        repository.salvar(novaMensagem("terceira", 12));

        List<Mensagem> resultado = repository.buscarUltimas(2);

        assertEquals(2, resultado.size());
        assertEquals("segunda", resultado.get(0).getConteudo());
        assertEquals("terceira", resultado.get(1).getConteudo());
    }

    private Mensagem novaMensagem(String conteudo, int minuto) {
        return new Mensagem(null, new Usuario("ana"), conteudo,
                LocalDateTime.of(2026, 10, 6, 10, minuto));
    }
}
