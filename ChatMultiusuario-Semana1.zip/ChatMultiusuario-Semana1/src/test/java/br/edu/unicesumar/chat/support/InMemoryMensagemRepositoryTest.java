package br.edu.unicesumar.chat.support;

import br.edu.unicesumar.chat.model.Mensagem;
import br.edu.unicesumar.chat.model.Usuario;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class InMemoryMensagemRepositoryTest {
    @Test
    void deveSalvarMensagemComIdERecuperarEmOrdemCronologica() {
        InMemoryMensagemRepository repository = new InMemoryMensagemRepository();
        Usuario usuario = new Usuario("ana");
        LocalDateTime horario = LocalDateTime.of(2026, 10, 6, 10, 0);

        Mensagem primeira = repository.salvar(
                new Mensagem(null, usuario, "primeira", horario));
        Mensagem segunda = repository.salvar(
                new Mensagem(null, usuario, "segunda", horario.plusMinutes(1)));

        List<Mensagem> resultado = repository.buscarUltimas(10);

        assertEquals(1L, primeira.getId());
        assertEquals(2L, segunda.getId());
        assertEquals(List.of(primeira, segunda), resultado);
    }

    @Test
    void deveRetornarSomenteAsUltimasNMensagens() {
        InMemoryMensagemRepository repository = new InMemoryMensagemRepository();
        Usuario usuario = new Usuario("ana");
        LocalDateTime horario = LocalDateTime.of(2026, 10, 6, 10, 0);

        for (int i = 1; i <= 4; i++) {
            repository.salvar(new Mensagem(null, usuario, "mensagem " + i,
                    horario.plusMinutes(i)));
        }

        List<Mensagem> resultado = repository.buscarUltimas(2);

        assertEquals(2, resultado.size());
        assertEquals("mensagem 3", resultado.get(0).getConteudo());
        assertEquals("mensagem 4", resultado.get(1).getConteudo());
    }

    @Test
    void deveRejeitarQuantidadeMenorQueUm() {
        InMemoryMensagemRepository repository = new InMemoryMensagemRepository();
        assertThrows(IllegalArgumentException.class, () -> repository.buscarUltimas(0));
    }
}
