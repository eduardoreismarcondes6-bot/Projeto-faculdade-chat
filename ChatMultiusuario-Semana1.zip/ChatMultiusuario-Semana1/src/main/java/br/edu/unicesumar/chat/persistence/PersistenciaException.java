package br.edu.unicesumar.chat.persistence;

/**
 * Encapsula falhas de infraestrutura de persistência sem expor SQLException.
 */
public class PersistenciaException extends RuntimeException {
    public PersistenciaException(String mensagem, Throwable causa) {
        super(mensagem, causa);
    }
}
