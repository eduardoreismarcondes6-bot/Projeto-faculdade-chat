package br.edu.unicesumar.chat.model;

/**
 * Indica que uma mensagem não atende às regras do domínio.
 */
public class MensagemInvalidaException extends RuntimeException {
    public MensagemInvalidaException(String mensagem) {
        super(mensagem);
    }
}
