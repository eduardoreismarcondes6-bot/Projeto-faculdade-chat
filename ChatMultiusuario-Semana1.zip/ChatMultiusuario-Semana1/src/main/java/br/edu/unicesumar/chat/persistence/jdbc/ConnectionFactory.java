package br.edu.unicesumar.chat.persistence.jdbc;

import br.edu.unicesumar.chat.config.Config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Objects;

/**
 * Cria uma conexão JDBC nova por operação.
 */
public final class ConnectionFactory {
    private final String url;
    private final String usuario;
    private final String senha;

    public ConnectionFactory(Config config) {
        Objects.requireNonNull(config, "A configuração é obrigatória.");
        this.url = config.getUrlBanco();
        this.usuario = config.getUsuarioBanco();
        this.senha = config.getSenhaBanco();
    }

    public Connection obterConexao() throws SQLException {
        return DriverManager.getConnection(url, usuario, senha);
    }
}
