package br.edu.unicesumar.chat.model;

import java.util.Locale;
import java.util.Objects;

/**
 * Representa um usuário do chat.
 * A classe é imutável: depois de criado, seu nome não pode ser alterado.
 */
public final class Usuario {
    public static final int TAMANHO_MAXIMO_NOME = 30;

    private final String nome;

    public Usuario(String nome) {
        if (nome == null) {
            throw new IllegalArgumentException("O nome do usuário não pode ser nulo.");
        }

        String nomeNormalizado = nome.trim();

        if (nomeNormalizado.isEmpty()) {
            throw new IllegalArgumentException("O nome do usuário não pode ser vazio.");
        }
        if (nomeNormalizado.length() > TAMANHO_MAXIMO_NOME) {
            throw new IllegalArgumentException(
                    "O nome do usuário deve ter no máximo " + TAMANHO_MAXIMO_NOME + " caracteres.");
        }
        if (nomeNormalizado.chars().anyMatch(Character::isWhitespace)) {
            throw new IllegalArgumentException("O nome do usuário não pode conter espaços.");
        }

        this.nome = nomeNormalizado;
    }

    public String getNome() {
        return nome;
    }

    @Override
    public boolean equals(Object objeto) {
        if (this == objeto) {
            return true;
        }
        if (!(objeto instanceof Usuario outro)) {
            return false;
        }
        return nome.toLowerCase(Locale.ROOT).equals(outro.nome.toLowerCase(Locale.ROOT));
    }

    @Override
    public int hashCode() {
        return Objects.hash(nome.toLowerCase(Locale.ROOT));
    }

    @Override
    public String toString() {
        return nome;
    }
}
