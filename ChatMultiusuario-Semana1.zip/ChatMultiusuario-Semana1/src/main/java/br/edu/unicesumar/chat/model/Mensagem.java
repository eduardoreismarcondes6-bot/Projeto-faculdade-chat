package br.edu.unicesumar.chat.model;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Objects;

/**
 * Representa uma mensagem do chat. Não conhece banco de dados nem rede.
 */
public final class Mensagem {
    public static final int TAMANHO_MAXIMO_CONTEUDO = 500;

    private static final DateTimeFormatter FORMATO_HORARIO =
            DateTimeFormatter.ofPattern("dd/MM HH:mm");

    private final Long id;
    private final Usuario remetente;
    private final String conteudo;
    private final LocalDateTime horario;

    public Mensagem(Long id, Usuario remetente, String conteudo, LocalDateTime horario) {
        if (remetente == null) {
            throw new MensagemInvalidaException("O remetente é obrigatório.");
        }
        if (conteudo == null) {
            throw new MensagemInvalidaException("O conteúdo da mensagem não pode ser nulo.");
        }

        String conteudoNormalizado = conteudo.trim();

        if (conteudoNormalizado.isEmpty()) {
            throw new MensagemInvalidaException("A mensagem não pode ser vazia.");
        }
        if (conteudoNormalizado.length() > TAMANHO_MAXIMO_CONTEUDO) {
            throw new MensagemInvalidaException(
                    "A mensagem deve ter no máximo " + TAMANHO_MAXIMO_CONTEUDO + " caracteres.");
        }
        if (horario == null) {
            throw new MensagemInvalidaException("O horário da mensagem é obrigatório.");
        }
        if (id != null && id <= 0) {
            throw new MensagemInvalidaException("O ID da mensagem deve ser positivo.");
        }

        this.id = id;
        this.remetente = remetente;
        this.conteudo = conteudoNormalizado;
        this.horario = horario;
    }

    public Long getId() {
        return id;
    }

    public Usuario getRemetente() {
        return remetente;
    }

    public String getConteudo() {
        return conteudo;
    }

    public LocalDateTime getHorario() {
        return horario;
    }

    /**
     * Retorna uma nova mensagem com o ID gerado pelo banco.
     */
    public Mensagem comId(Long novoId) {
        return new Mensagem(novoId, remetente, conteudo, horario);
    }

    public String formatar() {
        return "[" + horario.format(FORMATO_HORARIO) + "] "
                + remetente.getNome() + ": " + conteudo;
    }

    @Override
    public boolean equals(Object objeto) {
        if (this == objeto) {
            return true;
        }
        if (!(objeto instanceof Mensagem outra)) {
            return false;
        }
        return Objects.equals(id, outra.id)
                && remetente.equals(outra.remetente)
                && conteudo.equals(outra.conteudo)
                && horario.equals(outra.horario);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, remetente, conteudo, horario);
    }
}
