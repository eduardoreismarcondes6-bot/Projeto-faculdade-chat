package br.edu.unicesumar.chat.config;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * Carrega configurações de chat.properties.
 * Se o arquivo não existir, utiliza os valores padrão.
 */
public final class Config {
    private static final String ARQUIVO = "/chat.properties";

    private final String urlBanco;
    private final String usuarioBanco;
    private final String senhaBanco;
    private final int porta;
    private final int quantidadeHistorico;

    private Config(Properties propriedades) {
        this.urlBanco = propriedades.getProperty("db.url", "jdbc:h2:./data/chat").trim();
        this.usuarioBanco = propriedades.getProperty("db.user", "sa").trim();
        this.senhaBanco = propriedades.getProperty("db.password", "");
        this.porta = lerInteiro(propriedades, "server.port", 5000);
        this.quantidadeHistorico = lerInteiro(propriedades, "chat.history.limit", 50);

        if (porta < 1 || porta > 65535) {
            throw new IllegalArgumentException("server.port deve estar entre 1 e 65535.");
        }
        if (quantidadeHistorico < 1) {
            throw new IllegalArgumentException("chat.history.limit deve ser maior que zero.");
        }
    }

    public static Config carregar() {
        Properties propriedades = new Properties();

        try (InputStream entrada = Config.class.getResourceAsStream(ARQUIVO)) {
            if (entrada != null) {
                propriedades.load(entrada);
            }
        } catch (IOException e) {
            throw new IllegalStateException("Não foi possível ler chat.properties.", e);
        }

        return new Config(propriedades);
    }

    /**
     * Cria uma configuração a partir de propriedades; útil para testes.
     */
    public static Config dePropriedades(Properties propriedades) {
        return new Config(new Properties(propriedades));
    }

    private static int lerInteiro(Properties propriedades, String chave, int valorPadrao) {
        String valor = propriedades.getProperty(chave);
        if (valor == null || valor.isBlank()) {
            return valorPadrao;
        }
        try {
            return Integer.parseInt(valor.trim());
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Valor inválido para " + chave + ": " + valor, e);
        }
    }

    public String getUrlBanco() {
        return urlBanco;
    }

    public String getUsuarioBanco() {
        return usuarioBanco;
    }

    public String getSenhaBanco() {
        return senhaBanco;
    }

    public int getPorta() {
        return porta;
    }

    public int getQuantidadeHistorico() {
        return quantidadeHistorico;
    }
}
