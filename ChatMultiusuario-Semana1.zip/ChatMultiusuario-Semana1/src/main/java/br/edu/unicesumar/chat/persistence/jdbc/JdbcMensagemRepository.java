package br.edu.unicesumar.chat.persistence.jdbc;

import br.edu.unicesumar.chat.model.Mensagem;
import br.edu.unicesumar.chat.model.Usuario;
import br.edu.unicesumar.chat.persistence.MensagemRepository;
import br.edu.unicesumar.chat.persistence.PersistenciaException;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

/**
 * Implementação JDBC do repositório de mensagens.
 * Todo SQL do projeto fica nesta classe ou em recursos SQL.
 */
public final class JdbcMensagemRepository implements MensagemRepository {
    private static final String SQL_INSERIR = """
            INSERT INTO mensagem (remetente, conteudo, horario)
            VALUES (?, ?, ?)
            """;

    private static final String SQL_BUSCAR_ULTIMAS = """
            SELECT id, remetente, conteudo, horario
            FROM mensagem
            ORDER BY id DESC
            LIMIT ?
            """;

    private final ConnectionFactory connectionFactory;

    public JdbcMensagemRepository(ConnectionFactory connectionFactory) {
        this.connectionFactory = Objects.requireNonNull(
                connectionFactory, "ConnectionFactory é obrigatória.");
    }

    @Override
    public Mensagem salvar(Mensagem mensagem) {
        Objects.requireNonNull(mensagem, "A mensagem não pode ser nula.");

        try (Connection conexao = connectionFactory.obterConexao();
             PreparedStatement comando = conexao.prepareStatement(
                     SQL_INSERIR, Statement.RETURN_GENERATED_KEYS)) {

            comando.setString(1, mensagem.getRemetente().getNome());
            comando.setString(2, mensagem.getConteudo());
            comando.setTimestamp(3, Timestamp.valueOf(mensagem.getHorario()));

            int linhasAfetadas = comando.executeUpdate();
            if (linhasAfetadas != 1) {
                throw new SQLException("A inserção não confirmou exatamente uma linha.");
            }

            try (ResultSet chaves = comando.getGeneratedKeys()) {
                if (!chaves.next()) {
                    throw new SQLException("O banco não retornou o ID gerado.");
                }
                return mensagem.comId(chaves.getLong(1));
            }
        } catch (SQLException e) {
            throw new PersistenciaException("Erro ao salvar a mensagem.", e);
        }
    }

    @Override
    public List<Mensagem> buscarUltimas(int quantidade) {
        if (quantidade < 1) {
            throw new IllegalArgumentException("A quantidade deve ser maior que zero.");
        }

        List<Mensagem> mensagens = new ArrayList<>();

        try (Connection conexao = connectionFactory.obterConexao();
             PreparedStatement comando = conexao.prepareStatement(SQL_BUSCAR_ULTIMAS)) {

            comando.setInt(1, quantidade);

            try (ResultSet resultado = comando.executeQuery()) {
                while (resultado.next()) {
                    Usuario remetente = new Usuario(resultado.getString("remetente"));
                    Mensagem mensagem = new Mensagem(
                            resultado.getLong("id"),
                            remetente,
                            resultado.getString("conteudo"),
                            resultado.getTimestamp("horario").toLocalDateTime()
                    );
                    mensagens.add(mensagem);
                }
            }

            // A consulta busca da mais nova para a mais antiga.
            // A API entrega o resultado em ordem cronológica.
            Collections.reverse(mensagens);
            return List.copyOf(mensagens);

        } catch (SQLException e) {
            throw new PersistenciaException("Erro ao buscar o histórico de mensagens.", e);
        }
    }
}
