package br.edu.unicesumar.chat.persistence;

import br.edu.unicesumar.chat.model.Mensagem;

import java.util.List;

/**
 * Contrato de persistência de mensagens. Não expõe tipos JDBC.
 */
public interface MensagemRepository {
    Mensagem salvar(Mensagem mensagem);

    /**
     * Retorna até quantidade mensagens em ordem cronológica (antiga para nova).
     */
    List<Mensagem> buscarUltimas(int quantidade);
}
