# Chat Multiusuário — Semana 3

Projeto acadêmico em Java 17+ para o trabalho **Chat Multiusuário com Histórico**.

Nesta etapa foi implementado o servidor TCP com uma thread independente por conexão e um cliente de terminal. **O broadcast ainda não foi implementado**, conforme o cronograma: cada cliente recebe apenas a confirmação individual de que sua mensagem chegou ao servidor. O envio para todos os clientes será desenvolvido na Semana 4.

## 1. Requisitos

- JDK 17 ou superior (`java -version` e `javac -version`).
- H2 2.2.224: `lib\h2-2.2.224.jar` (necessário para os testes JDBC existentes).
- JUnit Platform Console Standalone 1.10.2: `lib\junit-platform-console-standalone-1.10.2.jar`.
- Windows CMD. Maven não é necessário.

## 2. Abrir a pasta correta do projeto

1. Extraia `ChatMultiusuario-Semana3.zip`.
2. Abra a pasta interna `ChatMultiusuario-Semana3` no VS Code.
3. No VS Code, abra **Terminal > Novo Terminal**. O terminal deve estar na pasta que contém `src`, `docs`, `README.md` e `pom.xml`.
4. Confirme com:

```cmd
cd
 dir
```

Se `dir` mostrar outra pasta `ChatMultiusuario-Semana3` dentro da pasta atual, entre nela com `cd ChatMultiusuario-Semana3`. Não execute os comandos na pasta externa.

## 3. Preparar as bibliotecas (somente na primeira vez ou se estiverem faltando)

Crie as pastas necessárias:

```cmd
if not exist lib mkdir lib
if not exist out mkdir out
if not exist test-out mkdir test-out
```

Confira os JARs:

```cmd
dir lib
```

Devem existir estes dois arquivos:

- `h2-2.2.224.jar`
- `junit-platform-console-standalone-1.10.2.jar`

Se você já os baixou na Semana 2, **não precisa baixar novamente**: copie a pasta `lib` do projeto da Semana 2 para a raiz deste projeto. Se não tiver os arquivos, baixe:

```cmd
curl.exe -fL "https://repo.maven.apache.org/maven2/com/h2database/h2/2.2.224/h2-2.2.224.jar" -o "lib\h2-2.2.224.jar"
curl.exe -fL "https://repo.maven.apache.org/maven2/org/junit/platform/junit-platform-console-standalone/1.10.2/junit-platform-console-standalone-1.10.2.jar" -o "lib\junit-platform-console-standalone-1.10.2.jar"
```

Se o download informar que não consegue abrir o arquivo de destino, confira se a pasta `lib` existe. Se aparecer `Could not resolve host`, verifique a conexão com a internet e tente novamente.

## 4. Compilar e executar todos os testes

A maneira mais simples é executar na raiz do projeto:

```cmd
testar.bat
```

O script compila as classes principais, copia os recursos, compila os testes e executa o JUnit. Também verifica se os JARs estão presentes e apresenta uma mensagem explicativa caso faltem.

### Execução manual (alternativa)

```cmd
if not exist out mkdir out
if not exist test-out mkdir test-out
dir /s /b src\main\java\*.java > fontes.txt
javac -encoding UTF-8 -cp "lib\h2-2.2.224.jar" -d out @fontes.txt
xcopy src\main\resources out\ /E /I /Y
dir /s /b src\test\java\*.java > testes.txt
javac -encoding UTF-8 -cp "out;lib\h2-2.2.224.jar;lib\junit-platform-console-standalone-1.10.2.jar" -d test-out @testes.txt
java -jar lib\junit-platform-console-standalone-1.10.2.jar execute --class-path "out;test-out;lib\h2-2.2.224.jar" --scan-class-path
```

O resultado esperado do JUnit é `0 tests failed`.

## 5. Executar o servidor e conectar clientes

Depois de executar `testar.bat` com sucesso, abra **um terminal** na raiz do projeto e inicie o servidor:

```cmd
java -cp "out;lib\h2-2.2.224.jar" br.edu.unicesumar.chat.server.Servidor
```

O servidor usa a porta `5000` por padrão, configurada em `src/main/resources/chat.properties`.

Abra **outro terminal** na mesma raiz e inicie um cliente:

```cmd
java -cp "out;lib\h2-2.2.224.jar" br.edu.unicesumar.chat.client.ClienteChat
```

Abra mais terminais e execute o mesmo comando para conectar outros clientes. Cada um deve informar um nickname diferente. Para testar em outro computador da mesma rede, informe o IP do computador que executa o servidor e a porta:

```cmd
java -cp "out;lib\h2-2.2.224.jar" br.edu.unicesumar.chat.client.ClienteChat 192.168.0.10 5000
```

Substitua `192.168.0.10` pelo IP real do computador servidor. O firewall do Windows pode solicitar autorização para Java receber conexões.

Digite mensagens no cliente. Nesta semana, o servidor registra as mensagens no terminal e devolve uma confirmação somente ao remetente. Digite `/sair` para desconectar. Para parar o servidor, use `Ctrl+C` no terminal dele.

## 6. O que foi implementado na Semana 3

- `server/Servidor`: abre `ServerSocket`, executa `accept()` e cria uma thread por conexão.
- `server/ClienteHandler`: atende uma única conexão, realiza o handshake do nickname e fecha recursos com segurança.
- `client/ClienteChat`: cliente de terminal com leitura de teclado e leitura do socket em threads separadas.
- `service/ConexaoCliente` e `service/ClientRegistry`: abstração da conexão e registro concorrente de nicknames, sem dependência de `java.net` ou JDBC.
- Encoding UTF-8 nos dois lados.
- Nickname duplicado é rejeitado sem diferenciar maiúsculas/minúsculas.
- Encerramento individual do cliente não derruba o servidor.

## 7. Problemas comuns

| Mensagem/problema | Causa provável e solução |
|---|---|
| `error: no source files` | Está na pasta errada ou o arquivo de lista ficou vazio. Confira `dir` e execute na raiz que contém `src`. |
| `The system cannot find the path specified` | O caminho `src\main\java` ou `src\test\java` não existe a partir da pasta atual. Entre na pasta interna do projeto. |
| `Unable to access jarfile ...` | O JAR não está em `lib`. Confira `dir lib` e copie/baixe os arquivos. |
| `package org.junit... does not exist` | O JUnit não foi incluído no `-cp` ou o JAR está ausente/incompleto. |
| `Address already in use` | A porta 5000 já está ocupada. Encerre o outro servidor ou altere `server.port` em `chat.properties`. |
| `Connection refused` | O servidor não está iniciado, o host/porta está incorreto ou o firewall bloqueou a conexão. |
| Nickname já conectado | Escolha outro nickname ou desconecte a sessão anterior. |

## Próxima etapa

Na Semana 4 será implementado o broadcast sincronizado: quando um cliente enviar uma mensagem, todos os clientes conectados receberão a mensagem. O núcleo de conexão individual desta semana será mantido.
