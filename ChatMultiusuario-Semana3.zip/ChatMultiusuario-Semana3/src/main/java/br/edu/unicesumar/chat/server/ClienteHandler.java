package br.edu.unicesumar.chat.server;

import br.edu.unicesumar.chat.model.Usuario;
import br.edu.unicesumar.chat.service.ClientRegistry;
import br.edu.unicesumar.chat.service.ConexaoCliente;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.Objects;

/** Atende exclusivamente uma conexão TCP, em sua própria thread. */
public final class ClienteHandler implements Runnable, ConexaoCliente {
    private final Socket socket;
    private final ClientRegistry registro;
    private volatile Usuario usuario;
    private volatile PrintWriter saida;

    public ClienteHandler(Socket socket, ClientRegistry registro) {
        this.socket = Objects.requireNonNull(socket, "Socket obrigatório.");
        this.registro = Objects.requireNonNull(registro, "Registro obrigatório.");
    }

    @Override
    public void run() {
        boolean registrado = false;
        try (Socket conexao = socket;
             BufferedReader entrada = new BufferedReader(new InputStreamReader(
                     conexao.getInputStream(), StandardCharsets.UTF_8));
             PrintWriter escritor = new PrintWriter(new OutputStreamWriter(
                     conexao.getOutputStream(), StandardCharsets.UTF_8), true)) {
            this.saida = escritor;
            enviar("Digite seu nickname:");
            String nickname = entrada.readLine();
            if (nickname == null) return;

            try {
                usuario = new Usuario(nickname);
            } catch (IllegalArgumentException e) {
                enviar("ERRO: nickname inválido. Use até 30 caracteres, sem espaços.");
                return;
            }

            if (!registro.registrar(this)) {
                enviar("ERRO: esse nickname já está conectado.");
                return;
            }
            registrado = true;
            enviar("Conectado como " + usuario.getNome() + ". Digite /sair para desconectar.");
            System.out.println("[CONECTADO] " + usuario.getNome() + " | clientes ativos: " + registro.quantidade());

            String linha;
            while ((linha = entrada.readLine()) != null) {
                if ("/sair".equalsIgnoreCase(linha.trim())) break;
                if (!linha.isBlank()) {
                    // Semana 3: recebe e confirma individualmente. Broadcast é da Semana 4.
                    System.out.println("[MENSAGEM DE " + usuario.getNome() + "] " + linha);
                    enviar("[CONFIRMAÇÃO] Mensagem recebida pelo servidor.");
                }
            }
        } catch (IOException e) {
            System.out.println("[CONEXÃO ENCERRADA] " + (usuario == null ? "cliente não identificado" : usuario.getNome())
                    + ": " + e.getMessage());
        } finally {
            if (registrado) {
                registro.remover(this);
                System.out.println("[DESCONECTADO] " + usuario.getNome()
                        + " | clientes ativos: " + registro.quantidade());
            }
        }
    }

    @Override
    public Usuario getUsuario() { return usuario; }

    @Override
    public synchronized void enviar(String linha) {
        PrintWriter escritor = saida;
        if (escritor != null) escritor.println(linha);
    }

    public void fechar() {
        try { socket.close(); } catch (IOException ignored) { /* encerramento */ }
    }
}
