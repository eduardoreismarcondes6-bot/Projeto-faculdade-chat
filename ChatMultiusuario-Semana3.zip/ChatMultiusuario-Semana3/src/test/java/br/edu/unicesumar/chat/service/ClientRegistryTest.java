package br.edu.unicesumar.chat.service;

import br.edu.unicesumar.chat.model.Usuario;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class ClientRegistryTest {
    private static final class ConexaoFake implements ConexaoCliente {
        private final Usuario usuario;
        ConexaoFake(String nome) { usuario = new Usuario(nome); }
        @Override public Usuario getUsuario() { return usuario; }
        @Override public void enviar(String linha) { }
    }

    @Test
    void registraClienteENumeraConexoes() {
        ClientRegistry registry = new ClientRegistry();
        assertTrue(registry.registrar(new ConexaoFake("ana")));
        assertEquals(1, registry.quantidade());
    }

    @Test
    void impedeNicknameDuplicadoSemDiferenciarMaiusculas() {
        ClientRegistry registry = new ClientRegistry();
        assertTrue(registry.registrar(new ConexaoFake("Ana")));
        assertFalse(registry.registrar(new ConexaoFake("ana")));
        assertEquals(1, registry.quantidade());
    }

    @Test
    void removeSomenteAConexaoRegistrada() {
        ClientRegistry registry = new ClientRegistry();
        ConexaoFake ana = new ConexaoFake("ana");
        registry.registrar(ana);
        registry.remover(new ConexaoFake("ana"));
        assertEquals(1, registry.quantidade());
        registry.remover(ana);
        assertEquals(0, registry.quantidade());
    }

    @Test
    void snapshotNaoPermiteAlterarRegistro() {
        ClientRegistry registry = new ClientRegistry();
        registry.registrar(new ConexaoFake("ana"));
        assertThrows(UnsupportedOperationException.class, () -> registry.snapshot().clear());
    }
}
