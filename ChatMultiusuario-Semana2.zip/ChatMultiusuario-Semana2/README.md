# Chat Multiusuário — Semana 2

Projeto acadêmico em Java 17+ para o trabalho **Chat Multiusuário com Histórico**.

Esta etapa consolida a organização em pacotes, a separação de responsabilidades e as regras do domínio. A comunicação por sockets ainda não foi implementada: ela pertence à Semana 3 do cronograma oficial.

## Requisitos

- JDK 17 ou superior.
- H2 2.2.224 para os testes JDBC.
- JUnit Platform Console Standalone 1.10.2 para executar os testes sem Maven.
- Maven continua opcional; o projeto pode ser compilado manualmente com `javac`.

## Estrutura atual

```text
src/
  main/java/br/edu/unicesumar/chat/
    config/                 # Leitura e validação de configurações
    model/                  # Entidades e regras puras do domínio
    persistence/            # Contrato do repositório e exceção de persistência
      jdbc/                 # Único pacote de produção que utiliza java.sql
  main/resources/           # schema.sql e chat.properties
  test/java/br/edu/unicesumar/chat/
    config/                 # Testes de configuração
    model/                  # Testes das regras de domínio
    persistence/            # Testes de integração JDBC com H2 em memória
    support/                # Repositório em memória usado nos testes
```

## Responsabilidades e dependências

- `model`: contém `Usuario`, `Mensagem` e `MensagemInvalidaException`. Não depende de banco, rede, arquivos ou configuração.
- `persistence`: define `MensagemRepository`, sem expor tipos JDBC.
- `persistence.jdbc`: implementa o contrato usando `PreparedStatement`, `try-with-resources` e uma conexão por operação.
- `config`: carrega configurações externas e fornece valores padrão.
- `support` (somente testes): fornece `InMemoryMensagemRepository`, permitindo testar sem banco real.

Direção principal: `persistence.jdbc` depende de `persistence` e `model`; `persistence` depende de `model`; `model` não depende das demais camadas.

## Compilação e testes sem Maven (Windows CMD)

Na pasta raiz do projeto, crie as pastas e coloque os dois JARs em `lib\`:

- `h2-2.2.224.jar`
- `junit-platform-console-standalone-1.10.2.jar`

Baixe-os, se necessário:

```cmd
mkdir lib
mkdir out
mkdir test-out
curl.exe -L "https://repo.maven.apache.org/maven2/com/h2database/h2/2.2.224/h2-2.2.224.jar" -o "lib\h2-2.2.224.jar"
curl.exe -L "https://repo.maven.apache.org/maven2/org/junit/platform/junit-platform-console-standalone/1.10.2/junit-platform-console-standalone-1.10.2.jar" -o "lib\junit-platform-console-standalone-1.10.2.jar"
```

Compile as classes principais:

```cmd
dir /s /b src\main\java\*.java > fontes.txt
javac -encoding UTF-8 -cp "lib\h2-2.2.224.jar" -d out @fontes.txt
xcopy src\main\resources out\ /E /I /Y
```

Compile os testes:

```cmd
dir /s /b src\test\java\*.java > testes.txt
javac -encoding UTF-8 -cp "out;lib\h2-2.2.224.jar;lib\junit-platform-console-standalone-1.10.2.jar" -d test-out @testes.txt
```

Execute todos os testes:

```cmd
java -jar lib\junit-platform-console-standalone-1.10.2.jar execute --class-path "out;test-out;lib\h2-2.2.224.jar" --scan-class-path
```

## Banco H2

A aplicação usa por padrão `jdbc:h2:./data/chat`. O script de criação está em `src/main/resources/schema.sql`. Os testes JDBC usam `jdbc:h2:mem:teste;DB_CLOSE_DELAY=-1`, separado do banco local.

## O que foi consolidado na Semana 2

- Pacotes organizados por responsabilidade, mantendo o pacote-base `br.edu.unicesumar.chat`.
- Entidades de domínio imutáveis e independentes de infraestrutura.
- Contrato de persistência separado da implementação JDBC.
- Testes unitários das regras de domínio sem rede e testes JDBC isolados com H2 em memória.
- Documento de arquitetura em `docs/ARQUITETURA.md`.

## Próxima etapa

Na Semana 3 serão adicionados o servidor TCP, o tratamento individual de cada conexão e o cliente de terminal. O broadcast ficará para a Semana 4, conforme a especificação oficial.
