package br.edu.unicesumar.chat.server;

import br.edu.unicesumar.chat.model.Mensagem;
import br.edu.unicesumar.chat.model.Usuario;
import br.edu.unicesumar.chat.persistence.MensagemRepository;
import br.edu.unicesumar.chat.service.ClientRegistry;
import br.edu.unicesumar.chat.service.ConexaoCliente;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Objects;

/** Atende uma conexão TCP, persistindo mensagens e disponibilizando o histórico. */
public final class ClienteHandler implements Runnable, ConexaoCliente {
    private final Socket socket;
    private final ClientRegistry registro;
    private final MensagemRepository mensagemRepository;
    private final int quantidadeHistorico;
    private volatile Usuario usuario;
    private volatile PrintWriter saida;

    public ClienteHandler(Socket socket, ClientRegistry registro,
                          MensagemRepository mensagemRepository, int quantidadeHistorico) {
        this.socket = Objects.requireNonNull(socket, "Socket obrigatório.");
        this.registro = Objects.requireNonNull(registro, "Registro obrigatório.");
        this.mensagemRepository = Objects.requireNonNull(
                mensagemRepository, "Repositório de mensagens obrigatório.");
        if (quantidadeHistorico < 1) {
            throw new IllegalArgumentException("A quantidade de histórico deve ser maior que zero.");
        }
        this.quantidadeHistorico = quantidadeHistorico;
    }

    @Override
    public void run() {
        boolean registrado = false;
        try (Socket conexao = socket;
             BufferedReader entrada = new BufferedReader(new InputStreamReader(
                     conexao.getInputStream(), StandardCharsets.UTF_8));
             PrintWriter escritor = new PrintWriter(new OutputStreamWriter(
                     conexao.getOutputStream(), StandardCharsets.UTF_8), true)) {
            this.saida = escritor;
            enviar("Digite seu nickname:");
            String nickname = entrada.readLine();
            if (nickname == null) return;

            try {
                usuario = new Usuario(nickname);
            } catch (IllegalArgumentException e) {
                enviar("ERRO: nickname inválido. Use até 30 caracteres, sem espaços.");
                return;
            }

            if (!registro.registrar(this)) {
                enviar("ERRO: esse nickname já está conectado.");
                return;
            }
            registrado = true;

            enviar("Conectado como " + usuario.getNome() + ". Digite /sair para desconectar.");
            enviarHistorico();
            System.out.println("[CONECTADO] " + usuario.getNome()
                    + " | clientes ativos: " + registro.quantidade());

            String linha;
            while ((linha = entrada.readLine()) != null) {
                if ("/sair".equalsIgnoreCase(linha.trim())) break;
                if (!linha.isBlank()) {
                    try {
                        Mensagem mensagem = new Mensagem(
                                null, usuario, linha, LocalDateTime.now());
                        Mensagem salva = mensagemRepository.salvar(mensagem);
                        String mensagemFormatada = salva.formatar();
                        System.out.println("[MENSAGEM] " + mensagemFormatada);
                        registro.broadcast(mensagemFormatada);
                    } catch (RuntimeException e) {
                        enviar("ERRO: não foi possível salvar sua mensagem. Tente novamente.");
                        System.err.println("[ERRO PERSISTENCIA] " + e.getMessage());
                    }
                }
            }
        } catch (IOException e) {
            System.out.println("[CONEXÃO ENCERRADA] "
                    + (usuario == null ? "cliente não identificado" : usuario.getNome())
                    + ": " + e.getMessage());
        } finally {
            if (registrado) {
                registro.remover(this);
                System.out.println("[DESCONECTADO] " + usuario.getNome()
                        + " | clientes ativos: " + registro.quantidade());
            }
        }
    }

    private void enviarHistorico() {
        try {
            List<Mensagem> historico = mensagemRepository.buscarUltimas(quantidadeHistorico);
            enviar("----- HISTÓRICO (" + historico.size() + " mensagens) -----");
            if (historico.isEmpty()) {
                enviar("Ainda não há mensagens no histórico.");
            } else {
                for (Mensagem mensagem : historico) enviar(mensagem.formatar());
            }
            enviar("----- FIM DO HISTÓRICO -----");
        } catch (RuntimeException e) {
            enviar("AVISO: não foi possível carregar o histórico.");
            System.err.println("[ERRO HISTORICO] " + e.getMessage());
        }
    }

    @Override
    public Usuario getUsuario() { return usuario; }

    @Override
    public synchronized void enviar(String linha) {
        PrintWriter escritor = saida;
        if (escritor != null) {
            escritor.println(linha);
            if (escritor.checkError()) {
                throw new IllegalStateException("Falha ao enviar dados para o cliente.");
            }
        }
    }

    public void fechar() {
        try { socket.close(); } catch (IOException ignored) { /* encerramento */ }
    }
}
