# Chat Multiusuário — Semana 5

Projeto acadêmico em Java: chat cliente-servidor TCP com múltiplos clientes, broadcast e histórico persistido em H2.

Nesta etapa, o servidor passa a salvar cada mensagem antes de distribuí-la e apresenta as últimas mensagens armazenadas quando um cliente entra.

## 1. Requisitos

- JDK 17 ou superior (use a mesma instalação para `java` e `javac`).
- Windows CMD.
- H2 2.2.224 e JUnit Platform Console Standalone 1.10.2 (os dois JARs acompanham este ZIP).
- Maven não é necessário.

## 2. Abrir a pasta correta

1. Extraia o ZIP.
2. Abra a pasta interna `ChatMultiusuario-Semana5` no VS Code.
3. Abra Terminal > Novo Terminal.
4. Confira com `cd` e `dir`. Você deve ver `src`, `docs`, `lib`, `README.md` e `testar.bat`.
5. Execute os comandos a partir dessa pasta, não da pasta externa que contém o ZIP extraído.

## 3. Conferir Java e bibliotecas

```cmd
java -version
javac -version
where java
where javac
if not exist lib mkdir lib
dir lib
```

Os dois comandos Java devem apontar para JDK 17 ou superior e, idealmente, para a mesma instalação. Se o `java` apontar para Java 8 e o `javac` para uma versão nova, ajuste temporariamente o terminal (adapte o caminho ao JDK instalado):

```cmd
set "JAVA_HOME=C:\Program Files\Eclipse Adoptium\jdk-24.0.2.12-hotspot"
set "PATH=%JAVA_HOME%\bin;%PATH%"
java -version
javac -version
```

Os arquivos necessários em `lib` são:
- `h2-2.2.224.jar`
- `junit-platform-console-standalone-1.10.2.jar`

Eles já estão incluídos. Se estiverem ausentes, baixe-os:

```cmd
curl.exe -fL "https://repo.maven.apache.org/maven2/com/h2database/h2/2.2.224/h2-2.2.224.jar" -o "lib\h2-2.2.224.jar"
curl.exe -fL "https://repo.maven.apache.org/maven2/org/junit/platform/junit-platform-console-standalone/1.10.2/junit-platform-console-standalone-1.10.2.jar" -o "lib\junit-platform-console-standalone-1.10.2.jar"
```

## 4. Compilar e executar os testes

Na raiz interna do projeto, execute:

```cmd
testar.bat
```

O script compila o código principal, copia os recursos, compila os testes e executa o JUnit. Resultado esperado: todos os testes aprovados e `0 tests failed`.

### Compilação manual (alternativa)

```cmd
if not exist out mkdir out
if not exist test-out mkdir test-out
dir /s /b src\main\java\*.java > fontes.txt
javac -encoding UTF-8 -cp "lib\h2-2.2.224.jar" -d out @fontes.txt
xcopy src\main\resources out\ /E /I /Y
dir /s /b src\test\java\*.java > testes.txt
javac -encoding UTF-8 -cp "out;lib\h2-2.2.224.jar;lib\junit-platform-console-standalone-1.10.2.jar" -d test-out @testes.txt
java -jar lib\junit-platform-console-standalone-1.10.2.jar execute --class-path "out;test-out;lib\h2-2.2.224.jar" --scan-class-path
```

## 5. Executar o servidor

Depois de compilar, inicie o servidor:

```cmd
java -cp "out;lib\h2-2.2.224.jar" br.edu.unicesumar.chat.server.Servidor
```

Na primeira execução, ao inicializar o banco, o servidor cria automaticamente a pasta `data` e o arquivo `chat.mv.db`. A tabela e o índice são criados automaticamente. **Não apague a pasta `data`** se quiser preservar o histórico.

Abra outros terminais na mesma pasta e inicie um cliente em cada terminal:

```cmd
java -cp "out;lib\h2-2.2.224.jar" br.edu.unicesumar.chat.client.ClienteChat
```

Informe um nickname diferente em cada cliente. Para encerrar um cliente, digite `/sair`. Para encerrar o servidor, use `Ctrl+C`.

Para conectar outro computador da mesma rede, use o IP do computador servidor:

```cmd
java -cp "out;lib\h2-2.2.224.jar" br.edu.unicesumar.chat.client.ClienteChat 192.168.0.10 5000
```

Substitua o IP pelo endereço real do servidor. O firewall do Windows pode solicitar autorização para receber conexões.

## 6. Como funciona o histórico

- O servidor carrega `chat.properties` e cria `ConnectionFactory`, `DatabaseInitializer` e `JdbcMensagemRepository`.
- `DatabaseInitializer` cria a tabela `mensagem` e o índice com `IF NOT EXISTS`; executar novamente não apaga os registros.
- Ao receber uma mensagem, o servidor cria um objeto `Mensagem` com remetente e horário atual.
- O `JdbcMensagemRepository` salva a mensagem no H2 e devolve o objeto com o ID gerado.
- Somente depois de salvar com sucesso a mensagem é distribuída aos clientes conectados.
- Ao conectar, o cliente recebe as últimas mensagens em ordem cronológica.
- O limite padrão do histórico enviado na conexão é 50 mensagens.

Configurações em `src/main/resources/chat.properties`:

```properties
db.url=jdbc:h2:./data/chat
db.user=sa
db.password=
server.port=5000
chat.history.limit=50
```

Para alterar o número de mensagens exibidas ao entrar, mude `chat.history.limit` para um inteiro maior que zero e execute novamente o servidor.

## 7. Teste manual recomendado

1. Execute `testar.bat`.
2. Inicie o servidor.
3. Abra dois clientes e envie algumas mensagens.
4. Digite `/sair` nos clientes e encerre o servidor.
5. Inicie o servidor novamente.
6. Conecte um novo cliente com outro nickname.
7. Confira se as mensagens da execução anterior aparecem no bloco `HISTÓRICO`.

O arquivo `data/chat.mv.db` deve permanecer no mesmo diretório de execução para o histórico continuar disponível.

## 8. Problemas comuns

| Problema | Solução |
|---|---|
| `UnsupportedClassVersionError` | `java` está mais antigo que `javac` ou que as classes. Confira as versões, ajuste `JAVA_HOME`/`Path`, apague `out` e `test-out` e rode `testar.bat`. |
| `error: no source files` | O CMD está na pasta errada. Confira `cd`, `dir` e a existência de `src\main\java`. |
| `Unable to access jarfile` | Confira se os JARs existem em `lib`. |
| `package org.junit... does not exist` | JUnit ausente ou classpath incorreto. Confira `lib` e rode `testar.bat`. |
| `Address already in use` | A porta 5000 já está ocupada. Encerre o outro servidor ou altere `server.port`. |
| `Connection refused` | Inicie o servidor e confira host, porta e firewall. |
| Nickname já conectado | Escolha outro nickname ou encerre a sessão anterior. |
| Erro ao inicializar banco | Confira se o processo tem permissão para criar/escrever na pasta de execução e se o JAR H2 está no classpath. |
| Histórico não aparece após reiniciar | Inicie o servidor a partir da mesma pasta do projeto e não remova `data/chat.mv.db`. |

## 9. O que foi realizado na Semana 5

- Integração do `MensagemRepository` com o servidor por injeção de dependência.
- Inicialização automática da tabela e do índice do banco H2.
- Persistência de mensagens recebidas antes do broadcast.
- Recuperação do histórico limitado e em ordem cronológica na conexão.
- Verificação de falhas de escrita no `PrintWriter` para detectar conexões com erro durante broadcast.
- Teste automatizado para criação idempotente da estrutura do banco e gravação/leitura após inicialização.

## Próxima etapa — Semana 6

Revisar concorrência e I/O, principalmente desconexões abruptas, falhas durante envio e estabilidade com vários clientes enviando mensagens.
