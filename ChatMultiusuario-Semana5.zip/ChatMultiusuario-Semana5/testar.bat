@echo off
setlocal
cd /d "%~dp0"
echo =============================================
echo Chat Multiusuario - Compilacao e testes
echo =============================================

if not exist src\main\java (
  echo ERRO: pasta src\main\java nao encontrada.
  echo Extraia o ZIP e execute este arquivo na raiz interna do projeto.
  pause
  exit /b 1
)
if not exist lib\h2-2.2.224.jar (
  echo ERRO: lib\h2-2.2.224.jar nao encontrado.
  echo Copie a pasta lib da Semana 2 ou siga a secao 3 do README.
  pause
  exit /b 1
)
if not exist lib\junit-platform-console-standalone-1.10.2.jar (
  echo ERRO: JUnit nao encontrado em lib\.
  echo Copie a pasta lib da Semana 2 ou siga a secao 3 do README.
  pause
  exit /b 1
)
if not exist out mkdir out
if not exist test-out mkdir test-out

echo [1/5] Localizando codigo principal...
dir /s /b src\main\java\*.java > fontes.txt
if errorlevel 1 goto erro
for %%A in (fontes.txt) do if %%~zA==0 (
  echo ERRO: nenhum arquivo Java principal foi encontrado.
  goto erro
)

echo [2/5] Compilando codigo principal...
javac -encoding UTF-8 -cp "lib\h2-2.2.224.jar" -d out @fontes.txt
if errorlevel 1 goto erro

echo [3/5] Copiando recursos...
if exist src\main\resources xcopy src\main\resources out\ /E /I /Y >nul

echo [4/5] Compilando testes...
dir /s /b src\test\java\*.java > testes.txt
if errorlevel 1 goto erro
for %%A in (testes.txt) do if %%~zA==0 (
  echo ERRO: nenhum arquivo de teste foi encontrado.
  goto erro
)
javac -encoding UTF-8 -cp "out;lib\h2-2.2.224.jar;lib\junit-platform-console-standalone-1.10.2.jar" -d test-out @testes.txt
if errorlevel 1 goto erro

echo [5/5] Executando JUnit...
java -jar lib\junit-platform-console-standalone-1.10.2.jar execute --class-path "out;test-out;lib\h2-2.2.224.jar" --scan-class-path
if errorlevel 1 goto erro

echo.
echo SUCESSO: compilacao e execucao dos testes concluidas.
pause
exit /b 0

:erro
echo.
echo FALHA: revise a mensagem acima. Consulte a secao 8 do README.
pause
exit /b 1
