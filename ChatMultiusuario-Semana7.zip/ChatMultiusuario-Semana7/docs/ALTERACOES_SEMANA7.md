# Semana 7 — Primeira etapa da interface gráfica

## Ajuste visual da tela de login

- Corrigida a renderização do botão **Conectar** em computadores Windows que utilizam o Look and Feel nativo.
- O botão agora utiliza `BasicButtonUI` para respeitar as cores personalizadas, com fundo roxo e texto branco legível.
- Adicionado cursor de mão para indicar que o botão é interativo.
- Nenhuma regra de conexão ou comunicação com o servidor foi alterada.

## Validação

- Compilação do código principal: aprovada.
- Compilação dos testes: aprovada.
- JUnit: 37 testes aprovados, 0 falhas.
