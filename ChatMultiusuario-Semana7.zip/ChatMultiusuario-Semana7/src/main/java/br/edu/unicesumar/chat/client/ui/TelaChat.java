package br.edu.unicesumar.chat.client.ui;

import br.edu.unicesumar.chat.client.network.ClienteSocket;
import br.edu.unicesumar.chat.client.ui.components.BalaoMensagem;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.plaf.basic.BasicButtonUI;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;

/** Janela principal do chat geral. A comunicação fica encapsulada em ClienteSocket. */
public final class TelaChat extends JFrame {
    private static final Color FUNDO = new Color(17, 24, 39);
    private static final Color PAINEL = new Color(25, 35, 52);
    private static final Color DESTAQUE = new Color(124, 92, 255);
    private static final Color TEXTO = new Color(235, 239, 247);
    private static final Color SECUNDARIO = new Color(160, 174, 195);

    private final String nickname;
    private final ClienteSocket cliente;
    private final JPanel mensagens = new JPanel();
    private final JTextField campoMensagem = new JTextField();
    private final JLabel status = new JLabel("● Conectado");

    public TelaChat(String nickname, ClienteSocket cliente) {
        super("Chat Multiusuário | " + nickname);
        this.nickname = nickname;
        this.cliente = cliente;
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        setSize(960, 680);
        setMinimumSize(new Dimension(680, 500));
        setLocationRelativeTo(null);
        montarInterface();
        addWindowListener(new WindowAdapter() {
            @Override public void windowClosed(WindowEvent e) { cliente.close(); }
        });
    }

    private void montarInterface() {
        JPanel raiz = new JPanel(new BorderLayout());
        raiz.setBackground(FUNDO);

        JPanel topo = new JPanel(new BorderLayout());
        topo.setBackground(PAINEL);
        topo.setBorder(new EmptyBorder(15, 22, 15, 22));

        JPanel identificacao = new JPanel();
        identificacao.setOpaque(false);
        identificacao.setLayout(new BoxLayout(identificacao, BoxLayout.Y_AXIS));
        JLabel titulo = new JLabel("Conversa geral");
        titulo.setForeground(TEXTO);
        titulo.setFont(new Font("SansSerif", Font.BOLD, 20));
        JLabel subtitulo = new JLabel("Você está conectado como " + nickname);
        subtitulo.setForeground(SECUNDARIO);
        subtitulo.setFont(new Font("SansSerif", Font.PLAIN, 12));
        identificacao.add(titulo);
        identificacao.add(Box.createVerticalStrut(3));
        identificacao.add(subtitulo);

        status.setForeground(new Color(130, 220, 165));
        status.setFont(new Font("SansSerif", Font.BOLD, 12));
        topo.add(identificacao, BorderLayout.WEST);
        topo.add(status, BorderLayout.EAST);

        mensagens.setLayout(new BoxLayout(mensagens, BoxLayout.Y_AXIS));
        mensagens.setBackground(FUNDO);
        mensagens.setBorder(new EmptyBorder(20, 22, 20, 22));

        JScrollPane rolagem = new JScrollPane(mensagens);
        rolagem.setBorder(BorderFactory.createEmptyBorder());
        rolagem.getViewport().setBackground(FUNDO);
        rolagem.getVerticalScrollBar().setUnitIncrement(18);
        rolagem.getVerticalScrollBar().setPreferredSize(new Dimension(10, 0));

        JPanel rodape = new JPanel(new BorderLayout(12, 0));
        rodape.setBackground(PAINEL);
        rodape.setBorder(new EmptyBorder(15, 18, 15, 18));

        campoMensagem.setFont(new Font("SansSerif", Font.PLAIN, 14));
        campoMensagem.setForeground(TEXTO);
        campoMensagem.setCaretColor(Color.WHITE);
        campoMensagem.setBackground(new Color(31, 43, 62));
        campoMensagem.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(65, 78, 100)),
                new EmptyBorder(12, 14, 12, 14)));
        campoMensagem.setToolTipText("Digite sua mensagem e pressione Enter");

        JButton enviar = criarBotao("Enviar");
        enviar.addActionListener(e -> enviarMensagem());
        campoMensagem.addActionListener(e -> enviarMensagem());

        rodape.add(campoMensagem, BorderLayout.CENTER);
        rodape.add(enviar, BorderLayout.EAST);

        raiz.add(topo, BorderLayout.NORTH);
        raiz.add(rolagem, BorderLayout.CENTER);
        raiz.add(rodape, BorderLayout.SOUTH);
        setContentPane(raiz);
    }

    private JButton criarBotao(String texto) {
        JButton botao = new JButton(texto);
        botao.setUI(new BasicButtonUI());
        botao.setOpaque(true);
        botao.setContentAreaFilled(true);
        botao.setBorderPainted(false);
        botao.setBackground(DESTAQUE);
        botao.setForeground(Color.WHITE);
        botao.setFocusPainted(false);
        botao.setFont(new Font("SansSerif", Font.BOLD, 13));
        botao.setBorder(new EmptyBorder(12, 22, 12, 22));
        botao.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        botao.setPreferredSize(new Dimension(105, 44));
        return botao;
    }

    public void receber(String linha) {
        SwingUtilities.invokeLater(() -> {
            boolean informativa = linha.startsWith("-----")
                    || linha.startsWith("Ainda não há")
                    || linha.startsWith("Conectado como");
            if (informativa) {
                JLabel aviso = new JLabel(linha);
                aviso.setForeground(SECUNDARIO);
                aviso.setFont(new Font("SansSerif", Font.ITALIC, 11));
                aviso.setAlignmentX(Component.CENTER_ALIGNMENT);
                mensagens.add(aviso);
            } else {
                boolean propria = linha.contains("] " + nickname + ":");
                mensagens.add(new BalaoMensagem(linha, propria));
            }
            mensagens.add(Box.createVerticalStrut(8));
            mensagens.revalidate();
            mensagens.repaint();
            SwingUtilities.invokeLater(() -> {
                JScrollBar barra = ((JScrollPane) mensagens.getParent().getParent()).getVerticalScrollBar();
                barra.setValue(barra.getMaximum());
            });
        });
    }

    private void enviarMensagem() {
        String texto = campoMensagem.getText().trim();
        if (texto.isEmpty()) return;
        try {
            cliente.enviar(texto);
            campoMensagem.setText("");
            campoMensagem.requestFocusInWindow();
        } catch (IOException e) {
            atualizarStatus(false);
            JOptionPane.showMessageDialog(this, e.getMessage(), "Falha no envio", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void atualizarStatus(boolean conectado) {
        status.setText(conectado ? "● Conectado" : "● Desconectado");
        status.setForeground(conectado ? new Color(130, 220, 165) : new Color(255, 130, 130));
    }

    public void desconectado(String motivo) {
        SwingUtilities.invokeLater(() -> {
            atualizarStatus(false);
            JOptionPane.showMessageDialog(this, motivo, "Conexão encerrada", JOptionPane.WARNING_MESSAGE);
        });
    }
}
