package br.edu.unicesumar.chat.client.ui;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.plaf.basic.BasicButtonUI;
import java.awt.*;
import java.util.function.BiConsumer;

/** Tela inicial para informar nickname e endereço do servidor. */
public final class TelaLogin extends JFrame {
    private static final Color FUNDO = new Color(17, 24, 39);
    private static final Color PAINEL = new Color(31, 41, 55);
    private static final Color DESTAQUE = new Color(124, 92, 255);
    private final JTextField nickname = new JTextField("", 20);
    private final JTextField host = new JTextField("localhost", 20);
    private final JTextField porta = new JTextField("5000", 20);
    private final JButton conectar = new JButton("Conectar");
    private final JLabel status = new JLabel("Informe seus dados para entrar.");

    public TelaLogin(BiConsumer<String, String[]> aoConectar) {
        super("Chat Multiusuário | Entrar");
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setSize(460, 570);
        setLocationRelativeTo(null);
        setResizable(false);
        JPanel base = new JPanel(new GridBagLayout());
        base.setBackground(FUNDO);
        JPanel card = new JPanel();
        card.setBackground(PAINEL);
        card.setBorder(new EmptyBorder(34, 34, 30, 34));
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));

        JLabel logo = new JLabel("CONVERSA");
        logo.setFont(new Font("SansSerif", Font.BOLD, 13));
        logo.setForeground(new Color(170, 150, 255));
        logo.setAlignmentX(Component.LEFT_ALIGNMENT);
        JLabel titulo = new JLabel("Bem-vindo ao chat");
        titulo.setFont(new Font("SansSerif", Font.BOLD, 27));
        titulo.setForeground(Color.WHITE);
        titulo.setAlignmentX(Component.LEFT_ALIGNMENT);
        JLabel subtitulo = new JLabel("Entre para começar a conversar.");
        subtitulo.setForeground(new Color(180, 190, 205));
        subtitulo.setAlignmentX(Component.LEFT_ALIGNMENT);
        card.add(logo); card.add(Box.createVerticalStrut(12)); card.add(titulo);
        card.add(Box.createVerticalStrut(7)); card.add(subtitulo); card.add(Box.createVerticalStrut(28));
        adicionarCampo(card, "Seu nickname", nickname);
        adicionarCampo(card, "Servidor", host);
        adicionarCampo(card, "Porta", porta);
        conectar.setAlignmentX(Component.LEFT_ALIGNMENT);
        conectar.setMaximumSize(new Dimension(Integer.MAX_VALUE, 44));
        // BasicButtonUI garante que as cores personalizadas sejam respeitadas
        // mesmo quando o Windows utiliza o Look and Feel nativo.
        conectar.setUI(new BasicButtonUI());
        conectar.setOpaque(true);
        conectar.setContentAreaFilled(true);
        conectar.setBorderPainted(false);
        conectar.setBackground(DESTAQUE);
        conectar.setForeground(Color.WHITE);
        conectar.setFocusPainted(false);
        conectar.setFont(new Font("SansSerif", Font.BOLD, 14));
        conectar.setBorder(BorderFactory.createEmptyBorder(10, 16, 10, 16));
        conectar.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        conectar.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override public void mouseEntered(java.awt.event.MouseEvent e) {
                conectar.setBackground(new Color(145, 115, 255));
            }
            @Override public void mouseExited(java.awt.event.MouseEvent e) {
                conectar.setBackground(DESTAQUE);
            }
        });
        conectar.addActionListener(e -> {
            String nome = nickname.getText().trim();
            if (nome.isEmpty()) { mostrarStatus("Digite um nickname.", true); return; }
            int numero;
            try { numero = Integer.parseInt(porta.getText().trim()); }
            catch (NumberFormatException ex) { mostrarStatus("A porta precisa ser numérica.", true); return; }
            if (numero < 1 || numero > 65535) { mostrarStatus("A porta deve estar entre 1 e 65535.", true); return; }
            conectar.setEnabled(false); conectar.setText("Conectando...");
            aoConectar.accept(nome, new String[]{host.getText().trim(), String.valueOf(numero)});
        });
        card.add(Box.createVerticalStrut(10)); card.add(conectar);
        status.setForeground(new Color(190, 200, 215)); status.setFont(new Font("SansSerif", Font.PLAIN, 12));
        status.setAlignmentX(Component.LEFT_ALIGNMENT);
        card.add(Box.createVerticalStrut(16)); card.add(status);
        base.add(card);
        setContentPane(base);
    }

    private void adicionarCampo(JPanel painel, String rotulo, JTextField campo) {
        JLabel label = new JLabel(rotulo);
        label.setForeground(new Color(220, 225, 235)); label.setFont(new Font("SansSerif", Font.BOLD, 12));
        label.setAlignmentX(Component.LEFT_ALIGNMENT);
        campo.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
        campo.setBackground(new Color(20, 29, 44));
        campo.setForeground(Color.WHITE); campo.setCaretColor(Color.WHITE);
        campo.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(new Color(65, 76, 96)),
                BorderFactory.createEmptyBorder(8, 10, 8, 10)));
        painel.add(label); painel.add(Box.createVerticalStrut(7)); painel.add(campo); painel.add(Box.createVerticalStrut(17));
    }

    public void mostrarStatus(String mensagem, boolean erro) {
        status.setText(mensagem); status.setForeground(erro ? new Color(255, 130, 130) : new Color(170, 220, 180));
    }
    public void restaurarBotao() { conectar.setEnabled(true); conectar.setText("Conectar"); }
}
