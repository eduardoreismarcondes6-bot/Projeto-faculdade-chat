package br.edu.unicesumar.chat.client;

import br.edu.unicesumar.chat.client.network.ClienteSocket;
import br.edu.unicesumar.chat.client.ui.TelaChat;
import br.edu.unicesumar.chat.client.ui.TelaLogin;

import javax.swing.*;
import java.io.IOException;

/** Ponto de entrada da versão gráfica do cliente. */
public final class ClienteChatSwing {
    private ClienteChatSwing() { }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try { UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); }
            catch (Exception ignored) { /* mantém o visual padrão do Swing */ }
            final TelaLogin[] referencia = new TelaLogin[1];
            referencia[0] = new TelaLogin((nickname, servidor) -> conectar(
                    referencia[0], nickname, servidor));
            referencia[0].setVisible(true);
        });
    }

    private static void conectar(TelaLogin login, String nickname, String[] servidor) {
        new SwingWorker<ClienteSocket, Void>() {
            @Override protected ClienteSocket doInBackground() throws IOException {
                return ClienteSocket.conectar(servidor[0], Integer.parseInt(servidor[1]), nickname);
            }
            @Override protected void done() {
                try {
                    ClienteSocket cliente = get();
                    TelaChat chat = new TelaChat(nickname, cliente);
                    cliente.iniciarLeitura(chat::receber, chat::desconectado);
                    chat.setVisible(true);
                    login.dispose();
                } catch (Exception e) {
                    login.restaurarBotao();
                    Throwable causa = e.getCause() == null ? e : e.getCause();
                    login.mostrarStatus("Não foi possível conectar: " + causa.getMessage(), true);
                }
            }
        }.execute();
    }
}
