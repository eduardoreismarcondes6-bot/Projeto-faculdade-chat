package br.edu.unicesumar.chat.client.network;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Consumer;

/** Encapsula a conexão TCP do cliente gráfico, sem depender de componentes Swing. */
public final class ClienteSocket implements AutoCloseable {
    private final Socket socket;
    private final BufferedReader entrada;
    private final PrintWriter saida;
    private final AtomicBoolean fechado = new AtomicBoolean();

    private ClienteSocket(Socket socket) throws IOException {
        this.socket = socket;
        this.entrada = new BufferedReader(new InputStreamReader(socket.getInputStream(), StandardCharsets.UTF_8));
        this.saida = new PrintWriter(new OutputStreamWriter(socket.getOutputStream(), StandardCharsets.UTF_8), true);
    }

    public static ClienteSocket conectar(String host, int porta, String nickname) throws IOException {
        Socket socket = new Socket(host, porta);
        ClienteSocket cliente = new ClienteSocket(socket);
        try {
            String prompt = cliente.entrada.readLine();
            if (prompt == null || prompt.startsWith("ERRO:")) {
                throw new IOException(prompt == null ? "O servidor encerrou a conexão." : prompt);
            }
            cliente.enviar(nickname);
            String resposta = cliente.entrada.readLine();
            if (resposta == null || resposta.startsWith("ERRO:")) {
                throw new IOException(resposta == null ? "O servidor encerrou a conexão." : resposta);
            }
            cliente.mensagemInicial = resposta;
            return cliente;
        } catch (IOException | RuntimeException e) {
            cliente.close();
            throw e;
        }
    }

    private String mensagemInicial;

    public void iniciarLeitura(Consumer<String> aoReceber, Consumer<String> aoDesconectar) {
        Objects.requireNonNull(aoReceber, "Callback de mensagens obrigatório.");
        Objects.requireNonNull(aoDesconectar, "Callback de desconexão obrigatório.");
        if (mensagemInicial != null) {
            aoReceber.accept(mensagemInicial);
            mensagemInicial = null;
        }
        iniciarLeituraInterna(aoReceber, aoDesconectar);
    }

    private void iniciarLeituraInterna(Consumer<String> aoReceber, Consumer<String> aoDesconectar) {
        Thread leitor = new Thread(() -> {
            String linha;
            try {
                while (!fechado.get() && (linha = entrada.readLine()) != null) aoReceber.accept(linha);
            } catch (IOException e) {
                if (!fechado.get()) aoDesconectar.accept("Conexão perdida: " + e.getMessage());
                return;
            }
            if (!fechado.get()) aoDesconectar.accept("O servidor encerrou a conexão.");
        }, "cliente-grafico-leitor");
        leitor.setDaemon(true);
        leitor.start();
    }

    public synchronized void enviar(String mensagem) throws IOException {
        if (fechado.get()) throw new IOException("Você não está conectado ao servidor.");
        saida.println(mensagem);
        if (saida.checkError()) throw new IOException("Não foi possível enviar a mensagem.");
    }

    @Override
    public void close() {
        if (fechado.compareAndSet(false, true)) {
            try { socket.close(); } catch (IOException ignored) { /* encerramento */ }
        }
    }
}
