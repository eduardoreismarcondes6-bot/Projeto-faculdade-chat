package br.edu.unicesumar.chat.client.ui.components;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

/** Balão visual alinhado conforme o remetente da mensagem. */
public final class BalaoMensagem extends JPanel {
    private static final Color PROPRIA = new Color(91, 70, 190);
    private static final Color RECEBIDA = new Color(43, 55, 73);

    public BalaoMensagem(String texto, boolean propria) {
        setLayout(new BorderLayout());
        setOpaque(false);
        setBorder(new EmptyBorder(3, 0, 3, 0));

        JPanel linha = new JPanel(new FlowLayout(propria ? FlowLayout.RIGHT : FlowLayout.LEFT, 0, 0));
        linha.setOpaque(false);

        JTextArea conteudo = new JTextArea(texto);
        conteudo.setEditable(false);
        conteudo.setLineWrap(true);
        conteudo.setWrapStyleWord(true);
        conteudo.setFocusable(false);
        conteudo.setOpaque(true);
        conteudo.setBackground(propria ? PROPRIA : RECEBIDA);
        conteudo.setForeground(Color.WHITE);
        conteudo.setFont(new Font("SansSerif", Font.PLAIN, 13));
        conteudo.setBorder(new EmptyBorder(10, 14, 10, 14));
        conteudo.setSize(380, Short.MAX_VALUE);
        Dimension tamanho = conteudo.getPreferredSize();
        int largura = Math.min(380, Math.max(110, tamanho.width));
        conteudo.setPreferredSize(new Dimension(largura, Math.max(38, tamanho.height)));
        linha.add(conteudo);
        add(linha, BorderLayout.CENTER);
    }
}
