# Chat Multiusuário — Semana 6

Projeto acadêmico em Java: chat cliente-servidor TCP com múltiplos clientes, broadcast e histórico persistido em H2.

Nesta etapa, a comunicação foi reforçada para lidar melhor com clientes lentos, falhas de envio e desconexões inesperadas. Cada conexão possui uma fila limitada de saída e uma thread dedicada à escrita no socket, separada da thread que lê as mensagens do cliente.

## 1. Requisitos

- JDK 17 ou superior.
- Windows CMD.
- Use a mesma instalação do JDK para `java` e `javac`.
- H2 2.2.224 e JUnit Platform Console Standalone 1.10.2 (os dois JARs acompanham este ZIP).
- Maven não é necessário.

## 2. Abrir a pasta correta

1. Extraia o ZIP.
2. Abra a pasta interna `ChatMultiusuario-Semana6` no VS Code.
3. Abra Terminal > Novo Terminal.
4. Confira com `cd` e `dir`. Você deve ver `src`, `docs`, `lib`, `README.md` e `testar.bat`.
5. Execute os comandos a partir dessa pasta, não da pasta externa que contém o ZIP extraído.

## 3. Conferir Java e bibliotecas

```cmd
java -version
javac -version
where java
where javac
if not exist lib mkdir lib
dir lib
```

Os dois comandos Java devem apontar para JDK 17 ou superior e, idealmente, para a mesma instalação. Se `java` apontar para Java 8 e `javac` para uma versão nova, ajuste temporariamente o terminal (adapte o caminho ao JDK instalado):

```cmd
set "JAVA_HOME=C:\Program Files\Eclipse Adoptium\jdk-24.0.2.12-hotspot"
set "PATH=%JAVA_HOME%\bin;%PATH%"
java -version
javac -version
```

Se abrir outro CMD, será necessário repetir os comandos acima, pois essa alteração vale somente para o terminal atual. O erro `UnsupportedClassVersionError` normalmente indica que o `java` usado para executar é mais antigo que o JDK usado para compilar.

Os arquivos necessários em `lib` são:
- `h2-2.2.224.jar`
- `junit-platform-console-standalone-1.10.2.jar`

Eles já estão incluídos. Se estiverem ausentes, baixe-os:

```cmd
curl.exe -fL "https://repo.maven.apache.org/maven2/com/h2database/h2/2.2.224/h2-2.2.224.jar" -o "lib\h2-2.2.224.jar"
curl.exe -fL "https://repo.maven.apache.org/maven2/org/junit/platform/junit-platform-console-standalone/1.10.2/junit-platform-console-standalone-1.10.2.jar" -o "lib\junit-platform-console-standalone-1.10.2.jar"
```

## 4. Compilar e executar os testes

Na raiz interna do projeto, execute:

```cmd
testar.bat
```

O script remove as compilações anteriores, compila o código principal, copia os recursos, compila os testes e executa o JUnit. Resultado esperado nesta versão: **37 testes aprovados e 0 falhas**.

### Compilação manual (alternativa)

```cmd
if exist out rmdir /s /q out
if exist test-out rmdir /s /q test-out
mkdir out
mkdir test-out
dir /s /b src\main\java\*.java > fontes.txt
javac -encoding UTF-8 -cp "lib\h2-2.2.224.jar" -d out @fontes.txt
xcopy src\main\resources out\ /E /I /Y
dir /s /b src\test\java\*.java > testes.txt
javac -encoding UTF-8 -cp "out;lib\h2-2.2.224.jar;lib\junit-platform-console-standalone-1.10.2.jar" -d test-out @testes.txt
java -jar lib\junit-platform-console-standalone-1.10.2.jar execute --class-path "out;test-out;lib\h2-2.2.224.jar" --scan-class-path
```

## 5. Executar o servidor

Depois de compilar, inicie o servidor:

```cmd
java -cp "out;lib\h2-2.2.224.jar" br.edu.unicesumar.chat.server.Servidor
```

Na primeira execução, o servidor cria automaticamente a pasta `data` e o arquivo `chat.mv.db`. A tabela e o índice são criados automaticamente. **Não apague a pasta `data`** se quiser preservar o histórico.

Abra outros terminais na mesma pasta e inicie um cliente em cada terminal:

```cmd
java -cp "out;lib\h2-2.2.224.jar" br.edu.unicesumar.chat.client.ClienteChat
```

Informe um nickname diferente em cada cliente. Para encerrar normalmente, digite `/sair`. Para encerrar o servidor, use `Ctrl+C`.

Para conectar outro computador da mesma rede, use o IP do computador servidor:

```cmd
java -cp "out;lib\h2-2.2.224.jar" br.edu.unicesumar.chat.client.ClienteChat 192.168.0.10 5000
```

Substitua o IP pelo endereço real do servidor. O firewall do Windows pode solicitar autorização para receber conexões.

## 6. O que foi reforçado na Semana 6

- A interface `ConexaoCliente` agora permite encerrar uma conexão com falha.
- O `ClientRegistry` continua serializando os broadcasts para manter a mesma ordem de enfileiramento para todos os clientes.
- O envio de cada cliente não escreve diretamente no socket durante o broadcast: a mensagem é inserida em uma fila de saída limitada.
- Cada `ClienteHandler` possui uma thread dedicada à escrita no socket, evitando que um cliente lento bloqueie a thread que recebe mensagens dos outros.
- A fila suporta até 500 linhas pendentes. Se ficar cheia, a conexão lenta é encerrada para proteger a estabilidade do servidor.
- Falhas de envio removem e fecham o cliente sem impedir a distribuição aos demais.
- Desconexões inesperadas encerram o handler e removem o nickname do registro.
- O servidor fecha os sockets dos clientes quando é encerrado.
- Foi adicionado teste de integração com socket real para simular o fechamento abrupto do cliente.

## 7. Testes manuais recomendados

1. Execute `testar.bat` e confira se todos os testes passam.
2. Inicie o servidor.
3. Abra três clientes com nicknames diferentes.
4. Envie mensagens a partir de dois clientes quase ao mesmo tempo. Confira se todos os clientes ativos recebem as mensagens.
5. Feche um dos terminais de cliente diretamente pelo botão X, sem digitar `/sair`.
6. Confira no terminal do servidor se aparece a desconexão e se os outros clientes continuam conversando.
7. Continue enviando mensagens pelos clientes restantes.
8. Encerre e reinicie o servidor; conecte um novo cliente e confira se o histórico continua disponível.

## 8. Como funciona a comunicação

- Cada cliente conectado é atendido por um `ClienteHandler`.
- A thread principal do handler lê as mensagens que chegam do socket.
- A mensagem é salva no H2 antes de ser distribuída.
- O `ClientRegistry` percorre um snapshot dos clientes e enfileira a mesma mensagem para cada um, mantendo a ordem de enfileiramento.
- Uma thread de escrita independente consome a fila de cada cliente e escreve no respectivo socket.
- Se a fila de um cliente encher ou a escrita falhar, somente aquela conexão é encerrada e removida.
- Ao conectar, o cliente continua recebendo as últimas mensagens do histórico em ordem cronológica.

## 9. Problemas comuns

| Problema | Solução |
|---|---|
| `UnsupportedClassVersionError` | `java` está mais antigo que `javac` ou que as classes. Ajuste `JAVA_HOME`/`Path` no CMD atual, confira `java -version` e `javac -version`, e rode `testar.bat`. |
| `error: no source files` | O CMD está na pasta errada. Confira `cd`, `dir` e a existência de `src\main\java`. |
| `Unable to access jarfile` | Confira se os JARs existem em `lib`. |
| `package org.junit... does not exist` | JUnit ausente ou classpath incorreto. Confira `lib` e rode `testar.bat`. |
| `Address already in use` | A porta 5000 já está ocupada. Encerre o outro servidor ou altere `server.port`. |
| `Connection refused` | Inicie o servidor e confira host, porta e firewall. |
| Nickname já conectado | Escolha outro nickname ou encerre a sessão anterior. |
| Histórico não aparece após reiniciar | Inicie o servidor a partir da mesma pasta do projeto e não remova `data\chat.mv.db`. |

## 10. Interface gráfica — Semana 7 (primeira versão)

A interface gráfica foi adicionada sem remover o cliente de terminal. A interface usa Java Swing e se comunica com o mesmo servidor TCP.

1. Execute `testar.bat` para compilar o projeto.
2. Em um terminal, inicie o servidor:

```cmd
java -cp "out;lib\h2-2.2.224.jar" br.edu.unicesumar.chat.server.Servidor
```

3. Em outro terminal, abra a interface gráfica:

```cmd
java -cp "out;lib\h2-2.2.224.jar" br.edu.unicesumar.chat.client.ClienteChatSwing
```

4. Informe nickname, host (`localhost` se o servidor estiver no mesmo computador) e porta (`5000` por padrão).
5. Para testar vários usuários, abra outra janela gráfica ou use o cliente de terminal em outro terminal.

### Organização da interface

- `client/ClienteChatSwing.java`: ponto de entrada da interface.
- `client/network/ClienteSocket.java`: conexão TCP e leitura/escrita, sem dependência de Swing.
- `client/ui/TelaLogin.java`: tela de entrada e validação dos campos.
- `client/ui/TelaChat.java`: janela de conversa e envio de mensagens.
- `client/ui/components/BalaoMensagem.java`: componente visual das mensagens.

A primeira versão utiliza nickname, pois o servidor atual ainda não possui cadastro de contas nem autenticação por senha. A senha será uma etapa posterior, com alterações próprias no modelo e no banco de dados.

## Próxima etapa

Evoluir a interface principal, revisar detalhes visuais e acrescentar testes de integração da comunicação gráfica. Depois disso, planejar cadastro/autenticação e personalização, mantendo as responsabilidades separadas.


## Cliente gráfico (Swing)

Depois de executar `testar.bat` e iniciar o servidor em um terminal, abra outro CMD na pasta raiz do projeto e execute:

```cmd
java -cp "out;lib\h2-2.2.224.jar" br.edu.unicesumar.chat.client.ClienteChatSwing
```

Entre com nickname, host e porta. O botão de envio e o campo de mensagem enviam mensagens para o mesmo servidor usado pelo cliente de terminal.
